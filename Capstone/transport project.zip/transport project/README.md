# Unified Intelligent Transportation System (UITS)
### Real GPS Distance + Real Transport Rates + Smart Route Recommendation

A complete, full-stack, intelligent multi-modal transportation comparison and route recommendation system designed for local city commutes and intercity journeys.

---

## 📌 Project Overview

The **Unified Intelligent Transportation System (UITS)** evaluates 12 different transportation modes dynamically based on real GPS distances, mode speeds, tiered transit tariff slabs, and a normalized Multi-Criteria Decision Analysis (MCDA) Smart Score algorithm.

### Key Capabilities:
- **Real GPS Geocoding & Autocomplete**: Powered by local high-precision GIS gazetteers and OpenStreetMap Nominatim. Supports neighbourhood-level resolution (e.g., Shenoy Nagar, Koyambedu CMBT, Anna Nagar, T. Nagar, Vadapalani, Guindy) without reducing to city centers.
- **Accurate Road Routing**: Computes driving distance and geometry using OSRM routing and empirical road tortuosity models (1.28x for urban grids, 1.16x for national highways).
- **12 Transportation Modes Compared**:
  - **Road Transportation (8)**: Rapido Bike, Auto Rickshaw, Ola Mini Cab, Uber Go, Ola Prime Cab, Uber Premier, Electric Taxi, Luxury Cab
  - **Public Transportation (4)**: Government Bus (MTC/TNSTC/SETC), Private Bus (Omni/Sleeper), Metro Train (CMRL Green/Blue lines), Suburban Train (Southern Railway EMU)
- **Automatic Best Route Recommendation**: Follows the PPT slide layout with a dedicated light-green recommendation card (`🏆 BEST ROUTE RECOMMENDATION`) and highlights the winning row in green in the comparison table.
- **Interactive Google Maps Live GPS Routing**: Leaflet map displaying source marker (A), destination marker (B), interactive popups, Google Maps navigation route polyline, and multi-layer switcher (Google Roadmap, Google Satellite, Google Hybrid, and Carto).
- **Google Maps Platform API Support**: Built-in option to connect an official Google Cloud API key for Places, Geocoding, and Directions APIs.

---

## 🏗️ System Architecture

```
transport project/
├── database/
│   ├── uits.db                    # SQLite3 database with locations, stations, fare slabs
│   └── init_db.py                 # Database initialization and seeding script
├── backend/
│   ├── config/
│   │   ├── __init__.py
│   │   └── pricing_config.py      # Base fares, km rates, slabs, Smart Score weights
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py             # Data models (Location, TransportOption, Recommendation)
│   ├── algorithms/
│   │   ├── __init__.py
│   │   ├── smart_score.py         # Normalized MCDA Smart Score algorithm
│   │   ├── route_engine.py        # Haversine distance, tortuosity, waypoint generator
│   │   └── time_estimator.py      # Mode-specific speeds, boarding & wait delays
│   ├── services/
│   │   ├── __init__.py
│   │   ├── geocoding_service.py   # Autocomplete & coordinate lookup
│   │   ├── pricing_service.py     # Road tariff & public transit slab calculator
│   │   ├── transit_service.py     # Metro & suburban rail corridor validator
│   │   └── routing_service.py     # Complete route comparison orchestration
│   ├── routes/
│   │   ├── __init__.py
│   │   └── api.py                 # REST API endpoints
│   ├── server.py                  # Standalone zero-dependency Python HTTP server
│   └── app.py                     # Flask application wrapper
├── frontend/
│   ├── index.html                 # HTML5 single page app with Leaflet & React 18
│   ├── styles.css                 # CSS stylesheet matching PPT requirements
│   └── app.js                     # React 18 component with interactive UI
├── test_uits.py                   # Automated verification test suite
├── run_uits.py                    # Unified Python runner with auto-browser launch
├── run_uits.bat                   # Double-click Windows batch launcher
└── README.md                      # Complete documentation
```

---

## 🧮 Mathematical Formulation & Algorithms

### 1. Geodesic Distance & Road Curvature Model
The great-circle geodesic distance is calculated using the Haversine formula:
$$\Delta\sigma = 2 \arcsin\left(\sqrt{\sin^2\left(\frac{\Delta\phi}{2}\right) + \cos(\phi_1)\cos(\phi_2)\sin^2\left(\frac{\Delta\lambda}{2}\right)}\right)$$
$$d_{\text{geodesic}} = R \times \Delta\sigma \quad (R = 6371.0088\text{ km})$$

Actual driving distance is computed using road network tortuosity factors:
- **Urban Dense City ($d_{\text{geodesic}} < 15\text{ km}$)**: $d_{\text{road}} = 1.28 \times d_{\text{geodesic}}$
- **Suburban Arterial ($15 \le d_{\text{geodesic}} < 45\text{ km}$)**: $d_{\text{road}} = 1.22 \times d_{\text{geodesic}}$
- **Intercity Highway ($d_{\text{geodesic}} \ge 45\text{ km}$)**: $d_{\text{road}} = 1.16 \times d_{\text{geodesic}}$

### 2. Multi-Criteria Smart Score Algorithm (MCDA)
Weights allocated according to project criteria:
- **Cost**: 45% (Lower is better)
- **Travel Time**: 35% (Lower is better)
- **Convenience**: 10% (Higher is better)
- **Availability**: 10% (Higher is better)

Dynamic Min-Max Normalization:
$$\text{Cost Score} = 100 \times \left(1 - \frac{\text{Cost} - \min(\text{Cost})}{\max(\text{Cost}) - \min(\text{Cost})}\right)$$
$$\text{Time Score} = 100 \times \left(1 - \frac{\text{Time} - \min(\text{Time})}{\max(\text{Time}) - \min(\text{Time})}\right)$$
$$\text{Smart Score} = 0.45 \times \text{Cost Score} + 0.35 \times \text{Time Score} + 0.10 \times \text{Convenience} + 0.10 \times \text{Availability}$$

The transport mode with the highest Smart Score is automatically recommended.

---

## 🚀 How to Run the Application

### Option 1: Double-click Windows Batch File
Double-click `run_uits.bat`. It will detect Python, ensure the SQLite database is populated, start the web server on `http://localhost:5000`, and open your default browser.

### Option 2: Python Command Line
```bash
python run_uits.py
```
Or specify a custom port:
```bash
python run_uits.py 8080
```

### Option 3: Run with Flask (if installed)
```bash
python backend/app.py
```

---

## 🚦 Verified Test Routes

Run the automated test suite anytime:
```bash
python test_uits.py
```

| Test | Source | Destination | Distance | Best Mode | Cost | Time | Status |
|---|---|---|---|---|---|---|---|
| **Test 1** | Shenoy Nagar | Koyambedu CMBT | 3.14 KM | **Metro Train** | ₹20.00 | 9 min | ✅ Passed |
| **Test 2** | Anna Nagar | T. Nagar | 6.99 KM | **Metro Train** | ₹40.00 | 15 min | ✅ Passed |
| **Test 3** | Vadapalani | Guindy | 6.31 KM | **Metro Train** | ₹40.00 | 14 min | ✅ Passed |
| **Test 4** | Tambaram | Velachery | 18.22 KM | **Suburban Train** | ₹10.00 | 36 min | ✅ Passed |
| **Test 5** | Chennai | Salem | 324.23 KM | **Private Bus** | ₹882.25 | 357 min | ✅ Passed |
| **Test 6** | Chennai | Coimbatore | 495.82 KM | **Private Bus** | ₹1216.85 | 523 min | ✅ Passed |

---

## 📡 REST API Reference

- `GET /api/health`: Health status and system configuration
- `GET /api/locations/search?q=shenoy`: Autocomplete location search
- `GET /api/locations/geocode?q=guindy`: Geocode a single location
- `POST /api/routes/compare`: Main comparison and smart recommendation calculation
  ```json
  {
    "source": "Shenoy Nagar",
    "destination": "Koyambedu CMBT"
  }
  ```
- `GET /api/history`: Recent route searches

---
Developed as a comprehensive, full-stack final year engineering solution.
