/**
 * Unified Intelligent Transportation System (UITS)
 * Zero-Dependency Node.js Development Server for `npm run dev`
 * Serves the web dashboard, Google Maps integration & complete REST API
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');
const { exec } = require('child_process');

const PORT = process.env.PORT || 5000;
const FRONTEND_DIR = path.join(__dirname, 'frontend');

// MIME types dictionary
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

// Embedded high-precision locations database
const LOCATIONS = [
  { name: "Shenoy Nagar", display_name: "Shenoy Nagar, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0784, lon: 80.2285, keywords: "shenoy nagar metro park thiru vi ka" },
  { name: "Koyambedu CMBT", display_name: "Chennai Mofussil Bus Terminus (CMBT), Koyambedu, Chennai", category: "bus_terminal", city: "Chennai", lat: 13.0694, lon: 80.2078, keywords: "koyambedu cmbt bus stand mofussil metro market" },
  { name: "Koyambedu", display_name: "Koyambedu, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0694, lon: 80.1948, keywords: "koyambedu junction market rohini silver screens" },
  { name: "Anna Nagar", display_name: "Anna Nagar, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0850, lon: 80.2101, keywords: "anna nagar roundtana tower park shanthi colony" },
  { name: "Anna Nagar East", display_name: "Anna Nagar East, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0872, lon: 80.2215, keywords: "anna nagar east metro roundtana chintamani" },
  { name: "Anna Nagar West", display_name: "Anna Nagar West, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0906, lon: 80.1983, keywords: "anna nagar west bus terminus millennium park" },
  { name: "T. Nagar", display_name: "Thyagaraya Nagar (T. Nagar), Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0418, lon: 80.2341, keywords: "t nagar panagal park ranganathan street pondy bazaar usman road" },
  { name: "Vadapalani", display_name: "Vadapalani, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0500, lon: 80.2121, keywords: "vadapalani andavar temple nexus vijaya mall metro" },
  { name: "Guindy", display_name: "Guindy, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0067, lon: 80.2025, keywords: "guindy race course kathipara junction industrial estate metro railway" },
  { name: "Ambattur", display_name: "Ambattur, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.1143, lon: 80.1548, keywords: "ambattur industrial estate ot railway station" },
  { name: "Kilpauk", display_name: "Kilpauk, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0788, lon: 80.2417, keywords: "kilpauk medical college kmc metro poonamallee" },
  { name: "Mogappair", display_name: "Mogappair, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0863, lon: 80.1762, keywords: "mogappair east west golden flats spartan" },
  { name: "Porur", display_name: "Porur, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0382, lon: 80.1565, keywords: "porur junction toll gate srmc ramachandra hospital" },
  { name: "Tambaram", display_name: "Tambaram, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 12.9249, lon: 80.1000, keywords: "tambaram railway station bus stand mcc college national highway" },
  { name: "Velachery", display_name: "Velachery, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 12.9756, lon: 80.2206, keywords: "velachery mrts railway station phoenix marketcity bypass road" },
  { name: "Adyar", display_name: "Adyar, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0012, lon: 80.2565, keywords: "adyar signal lb road gandhi nagar cancer institute" },
  { name: "Marina Beach", display_name: "Marina Beach, Chennai, Tamil Nadu", category: "landmark", city: "Chennai", lat: 13.0500, lon: 80.2824, keywords: "marina beach lighthouse kamarajar salai bay of bengal" },
  { name: "Chennai Central", display_name: "Puratchi Thalaivar Dr. MGR Central Railway Station, Chennai", category: "railway_station", city: "Chennai", lat: 13.0827, lon: 80.2755, keywords: "chennai central mgr central railway station ripon central metro" },
  { name: "Egmore", display_name: "Chennai Egmore Railway Station, Chennai", category: "railway_station", city: "Chennai", lat: 13.0792, lon: 80.2614, keywords: "chennai egmore railway station museum metro" },
  { name: "Chennai Airport", display_name: "Chennai International Airport (MAA), Meenambakkam, Chennai", category: "airport", city: "Chennai", lat: 12.9941, lon: 80.1709, keywords: "chennai airport maa terminal domestic international meenambakkam metro" },
  { name: "Perambur", display_name: "Perambur, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.1112, lon: 80.2422, keywords: "perambur railway station loco works icf carriage works" },
  { name: "Mylapore", display_name: "Mylapore, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0368, lon: 80.2676, keywords: "mylapore kapaleeshwarar temple luz corner santhome" },
  { name: "Nungambakkam", display_name: "Nungambakkam, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0595, lon: 80.2425, keywords: "nungambakkam high road loyola college sterling road" },
  { name: "Saidapet", display_name: "Saidapet, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0213, lon: 80.2231, keywords: "saidapet court metro railway station anna salai" },
  { name: "Thiruvanmiyur", display_name: "Thiruvanmiyur, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 12.9830, lon: 80.2594, keywords: "thiruvanmiyur bus stand beach tidel park" },
  { name: "Sholinganallur", display_name: "Sholinganallur, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 12.9010, lon: 80.2279, keywords: "sholinganallur junction omr it corridor elcot sez" },
  { name: "Chromepet", display_name: "Chromepet, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 12.9516, lon: 80.1462, keywords: "chromepet railway station mit college gst road" },
  { name: "Pallavaram", display_name: "Pallavaram, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 12.9675, lon: 80.1491, keywords: "pallavaram railway station gst road" },
  { name: "Avadi", display_name: "Avadi, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.1147, lon: 80.1009, keywords: "avadi railway station hvf tank factory crpf" },
  { name: "Poonamallee", display_name: "Poonamallee, Chennai, Tamil Nadu", category: "neighborhood", city: "Chennai", lat: 13.0489, lon: 80.1098, keywords: "poonamallee bypass bus terminus trunk road" },
  { name: "Chennai", display_name: "Chennai, Tamil Nadu", category: "city", city: "Chennai", lat: 13.0827, lon: 80.2707, keywords: "chennai madras capital" },
  { name: "Salem", display_name: "Salem, Tamil Nadu", category: "city", city: "Salem", lat: 11.6643, lon: 78.1460, keywords: "salem junction bus stand steel plant" },
  { name: "Coimbatore", display_name: "Coimbatore, Tamil Nadu", category: "city", city: "Coimbatore", lat: 11.0168, lon: 76.9558, keywords: "coimbatore covai gandhipuram railway station textile" },
  { name: "Madurai", display_name: "Madurai, Tamil Nadu", category: "city", city: "Madurai", lat: 9.9252, lon: 78.1198, keywords: "madurai meenakshi amman temple mattuthavani" },
  { name: "Vellore", display_name: "Vellore, Tamil Nadu", category: "city", city: "Vellore", lat: 12.9165, lon: 79.1325, keywords: "vellore fort cmc hospital golden temple" },
  { name: "Trichy", display_name: "Tiruchirappalli (Trichy), Tamil Nadu", category: "city", city: "Trichy", lat: 10.7905, lon: 78.7047, keywords: "trichy tiruchirappalli rockfort srirangam" },
  { name: "Tirunelveli", display_name: "Tirunelveli, Tamil Nadu", category: "city", city: "Tirunelveli", lat: 8.7139, lon: 77.7567, keywords: "tirunelveli nellai halwa junction" },
  { name: "Erode", display_name: "Erode, Tamil Nadu", category: "city", city: "Erode", lat: 11.3410, lon: 77.7172, keywords: "erode junction turmeric textile" },
  { name: "Tiruppur", display_name: "Tiruppur, Tamil Nadu", category: "city", city: "Tiruppur", lat: 11.1085, lon: 77.3411, keywords: "tiruppur knitwear export hub" },
  { name: "Hosur", display_name: "Hosur, Tamil Nadu", category: "city", city: "Hosur", lat: 12.7409, lon: 77.8253, keywords: "hosur sipcot industrial bangalore border" },
  { name: "Pondicherry", display_name: "Puducherry (Pondicherry)", category: "city", city: "Pondicherry", lat: 11.9416, lon: 79.8083, keywords: "pondicherry puducherry promenade beach" }
];

const SEARCH_HISTORY = [];

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371.0088;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function generateWaypoints(lat1, lon1, lat2, lon2, distKm) {
  const points = [];
  const steps = distKm < 25 ? 20 : 35;
  const dLat = lat2 - lat1;
  const dLon = lon2 - lon1;

  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const baseLat = lat1 + t * dLat;
    const baseLon = lon1 + t * dLon;
    const sway = Math.sin(t * Math.PI * 2) * (distKm < 25 ? 0.002 : 0.008);
    points.push([Number((baseLat - dLon * 0.05 * sway).toFixed(6)), Number((baseLon + dLat * 0.05 * sway).toFixed(6))]);
  }
  points[0] = [lat1, lon1];
  points[points.length - 1] = [lat2, lon2];
  return points;
}

function computeRoute(srcQuery, dstQuery) {
  const find = (q) => {
    const clean = q.trim().toLowerCase();
    for (let l of LOCATIONS) {
      if (l.name.toLowerCase() === clean || l.name.toLowerCase().includes(clean)) return l;
    }
    for (let l of LOCATIONS) {
      if (l.keywords.includes(clean) || l.display_name.toLowerCase().includes(clean)) return l;
    }
    return null;
  };

  const src = find(srcQuery);
  const dst = find(dstQuery);
  if (!src || !dst) return null;

  const directKm = haversineKm(src.lat, src.lon, dst.lat, dst.lon);
  const isIntercity = directKm > 45.0;
  const roadFactor = directKm < 15.0 ? 1.28 : (directKm < 45.0 ? 1.22 : 1.16);
  const roadKm = Number((directKm * roadFactor).toFixed(2));
  const routeType = isIntercity ? "intercity" : (directKm < 15.0 ? "local_urban" : "local_suburban");

  const modeDefs = [
    { code: "rapido_bike", name: "Rapido Bike", category: "Road", baseFare: 25, baseKm: 1.5, perKm: 8.0, minFare: 25, speed: 32, maxKm: 45, conv: 72, avail: 94 },
    { code: "auto_rickshaw", name: "Auto Rickshaw", category: "Road", baseFare: 35, baseKm: 1.8, perKm: 15.0, minFare: 35, speed: 26, maxKm: 40, conv: 76, avail: 95 },
    { code: "ola_mini", name: "Ola Mini Cab", category: "Road", baseFare: 50, baseKm: 2.0, perKm: isIntercity ? 12.0 : 14.0, minFare: 90, speed: isIntercity ? 68 : 26, maxKm: 800, conv: 84, avail: 92 },
    { code: "uber_go", name: "Uber Go", category: "Road", baseFare: 55, baseKm: 2.0, perKm: isIntercity ? 12.5 : 14.5, minFare: 95, speed: isIntercity ? 68 : 26, maxKm: 800, conv: 85, avail: 93 },
    { code: "ola_prime", name: "Ola Prime Cab", category: "Road", baseFare: 75, baseKm: 2.0, perKm: isIntercity ? 14.5 : 17.0, minFare: 130, speed: isIntercity ? 72 : 28, maxKm: 1000, conv: 91, avail: 89 },
    { code: "uber_premier", name: "Uber Premier", category: "Road", baseFare: 85, baseKm: 2.0, perKm: isIntercity ? 16.0 : 19.0, minFare: 150, speed: isIntercity ? 74 : 28, maxKm: 1000, conv: 94, avail: 86 },
    { code: "electric_taxi", name: "Electric Taxi", category: "Road", baseFare: 60, baseKm: 2.0, perKm: 15.0, minFare: 100, speed: isIntercity ? 65 : 27, maxKm: 120, conv: 90, avail: 84 },
    { code: "luxury_cab", name: "Luxury Cab", category: "Road", baseFare: 180, baseKm: 3.0, perKm: isIntercity ? 22.0 : 26.0, minFare: 350, speed: isIntercity ? 78 : 30, maxKm: 1000, conv: 98, avail: 75 },
    { code: "govt_bus", name: "Government Bus", category: "Public", isSlab: true, speed: isIntercity ? 55 : 20, conv: 65, avail: 96 },
    { code: "private_bus", name: "Private Bus", category: "Public", isPrivateBus: true, speed: isIntercity ? 62 : 22, conv: 82, avail: 88 },
    { code: "metro_train", name: "Metro Train", category: "Public", isMetro: true, speed: 38, conv: 93, avail: 97 },
    { code: "suburban_train", name: "Suburban Train", category: "Public", isSuburban: true, speed: 36, conv: 78, avail: 92 }
  ];

  const options = [];

  for (let m of modeDefs) {
    let isAvail = true;
    let status = "Available";
    let cost = 0;
    let ratePerKm = 0;
    let timeMin = 0;

    if (m.isMetro) {
      if (isIntercity || roadKm > 45.0) {
        isAvail = false;
        status = "Unavailable (No Intercity Metro)";
      } else {
        isAvail = true;
        status = "Available (CMRL Green/Blue Line)";
        if (roadKm <= 2.0) cost = 10;
        else if (roadKm <= 4.0) cost = 20;
        else if (roadKm <= 6.0) cost = 30;
        else if (roadKm <= 9.0) cost = 40;
        else cost = 50;
        ratePerKm = Number((cost / Math.max(roadKm, 1.0)).toFixed(2));
        timeMin = Math.max(4, Math.round((roadKm / m.speed) * 60) + 4);
      }
    } else if (m.isSuburban) {
      if (isIntercity || roadKm > 75.0) {
        isAvail = false;
        status = "Unavailable (No Suburban Line)";
      } else {
        isAvail = true;
        status = "Available (Southern Railway EMU)";
        if (roadKm <= 10.0) cost = 5;
        else if (roadKm <= 45.0) cost = 10;
        else cost = 15;
        ratePerKm = Number((cost / Math.max(roadKm, 1.0)).toFixed(2));
        timeMin = Math.max(5, Math.round((roadKm / m.speed) * 60) + 6);
      }
    } else if (m.isSlab) {
      if (isIntercity) {
        status = "Available (TNSTC / SETC)";
        ratePerKm = 1.25;
        cost = Math.max(50.0, Number((roadKm * ratePerKm).toFixed(2)));
        timeMin = Math.round((roadKm / m.speed) * 60) + 12;
      } else {
        status = "Available (MTC City Bus)";
        if (roadKm <= 2.0) cost = 5;
        else if (roadKm <= 4.0) cost = 9;
        else if (roadKm <= 7.0) cost = 12;
        else if (roadKm <= 12.0) cost = 15;
        else if (roadKm <= 18.0) cost = 19;
        else if (roadKm <= 26.0) cost = 23;
        else cost = 28;
        ratePerKm = Number((cost / Math.max(roadKm, 1.0)).toFixed(2));
        timeMin = Math.max(5, Math.round((roadKm / m.speed) * 60) + 8);
      }
    } else if (m.isPrivateBus) {
      if (isIntercity) {
        status = "Available (Omni / AC Sleeper)";
        ratePerKm = 1.95;
        cost = Number((250.0 + (roadKm * ratePerKm)).toFixed(2));
        timeMin = Math.round((roadKm / m.speed) * 60) + 15;
      } else {
        status = "Available (Private Feeder)";
        ratePerKm = 2.2;
        cost = Number((15.0 + (roadKm * ratePerKm)).toFixed(2));
        timeMin = Math.round((roadKm / m.speed) * 60) + 8;
      }
    } else {
      if (roadKm > m.maxKm) {
        isAvail = false;
        status = `Unavailable (> ${m.maxKm} KM Limit)`;
      } else {
        ratePerKm = m.perKm;
        const distCharge = roadKm <= m.baseKm ? 0 : (roadKm - m.baseKm) * ratePerKm;
        cost = Math.max(m.minFare, Number((m.baseFare + distCharge).toFixed(2)));
        timeMin = Math.max(3, Math.round((roadKm / m.speed) * 60) + 4);
      }
    }

    options.push({
      mode: m.name,
      code: m.code,
      category: m.category,
      rate_per_km: ratePerKm,
      distance_km: roadKm,
      time_minutes: timeMin,
      cost: cost,
      smart_score: 0.0,
      status: status,
      is_available: isAvail,
      is_recommended: false,
      breakdown: { conv: m.conv, avail: m.avail }
    });
  }

  // Smart Score Normalization
  const availableOpts = options.filter(o => o.is_available);
  if (availableOpts.length > 0) {
    const costs = availableOpts.map(o => o.cost);
    const times = availableOpts.map(o => o.time_minutes);
    const minC = Math.min(...costs), maxC = Math.max(...costs);
    const minT = Math.min(...times), maxT = Math.max(...times);
    const rangeC = maxC > minC ? (maxC - minC) : 1;
    const rangeT = maxT > minT ? (maxT - minT) : 1;

    let bestOpt = null;
    let highestScore = -1;

    for (let opt of availableOpts) {
      const costScore = 100 * (1 - (opt.cost - minC) / rangeC);
      const timeScore = 100 * (1 - (opt.time_minutes - minT) / rangeT);
      const score = Number((0.45 * costScore + 0.35 * timeScore + 0.10 * opt.breakdown.conv + 0.10 * opt.breakdown.avail).toFixed(1));
      opt.smart_score = score;

      if (score > highestScore) {
        highestScore = score;
        bestOpt = opt;
      }
    }

    if (bestOpt) bestOpt.is_recommended = true;

    const recommendation = bestOpt ? {
      source_name: src.name,
      dest_name: dst.name,
      total_distance_km: roadKm,
      best_mode: bestOpt.mode,
      estimated_time_minutes: bestOpt.time_minutes,
      estimated_cost: bestOpt.cost,
      smart_score: bestOpt.smart_score,
      status: "BEST OPTION",
      reasoning: `${bestOpt.mode} achieved the highest Smart Score (${bestOpt.smart_score}/100) with optimal cost (₹${bestOpt.cost}), travel time (${bestOpt.time_minutes} min), and accessibility.`
    } : null;

    const result = {
      source: { name: src.name, display_name: src.display_name, latitude: src.lat, longitude: src.lon },
      destination: { name: dst.name, display_name: dst.display_name, latitude: dst.lat, longitude: dst.lon },
      distance_km: roadKm,
      direct_distance_km: Number(directKm.toFixed(2)),
      route_type: routeType,
      coordinates: generateWaypoints(src.lat, src.lon, dst.lat, dst.lon, directKm),
      options: options,
      recommendation: recommendation
    };

    SEARCH_HISTORY.unshift({
      source: src.name,
      destination: dst.name,
      distance_km: roadKm,
      best_mode: bestOpt ? bestOpt.mode : "N/A",
      cost: bestOpt ? bestOpt.cost : 0,
      time: bestOpt ? bestOpt.time_minutes : 0,
      smart_score: bestOpt ? bestOpt.smart_score : 0,
      searched_at: new Date().toISOString()
    });
    if (SEARCH_HISTORY.length > 15) SEARCH_HISTORY.pop();

    return result;
  }
  return null;
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  let pathname = parsedUrl.pathname;

  // Enable CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // REST API Endpoints
  if (pathname === '/api/health') {
    const acceptsHtml = (req.headers.accept || '').includes('text/html');
    if (acceptsHtml) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>UITS API Health - Operational</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', -apple-system, sans-serif; background: #f8fafc; display: flex; align-items: center; justify-content: center; min-height: 100vh; margin: 0; padding: 20px; box-sizing: border-box; }
    .card { background: white; border-radius: 20px; padding: 40px; max-width: 520px; width: 100%; box-shadow: 0 10px 25px rgba(0,0,0,0.06); border: 1.5px solid #e2e8f0; text-align: center; }
    .badge { background: #dcfce7; color: #15803d; border: 1px solid #86efac; padding: 6px 16px; border-radius: 9999px; font-weight: 800; font-size: 13px; display: inline-flex; align-items: center; gap: 6px; margin-bottom: 18px; }
    h1 { font-size: 22px; font-weight: 800; color: #0f172a; margin: 0 0 8px 0; }
    p { font-size: 14px; color: #64748b; margin: 0 0 24px 0; line-height: 1.5; }
    .btn { background: #16a34a; color: white; padding: 14px 28px; border-radius: 10px; font-weight: 700; font-size: 15px; text-decoration: none; display: inline-block; transition: background 0.2s; box-shadow: 0 4px 12px rgba(22, 163, 74, 0.25); }
    .btn:hover { background: #15803d; }
    .info-box { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; margin-top: 24px; text-align: left; font-size: 13px; line-height: 1.8; color: #334155; }
  </style>
</head>
<body>
  <div class="card">
    <div class="badge">🟢 API HEALTH: OPERATIONAL</div>
    <h1>Unified Intelligent Transportation System (UITS)</h1>
    <p>The backend routing, tariff calculation, and Google Maps services are active and ready.</p>
    <a href="/" class="btn">👉 Open Web Dashboard</a>
    <div class="info-box">
      <div><strong>Status:</strong> 200 OK (Healthy)</div>
      <div><strong>Engine:</strong> Google Maps + High-Precision GPS</div>
      <div><strong>Modes Evaluated:</strong> 12 Transportation Modes</div>
      <div><strong>Multi-Criteria Algorithm:</strong> MCDA Smart Score (Cost 45%, Time 35%)</div>
    </div>
  </div>
</body>
</html>`);
      return;
    }

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'healthy',
      system: 'Unified Intelligent Transportation System (UITS)',
      version: '2.0.0',
      gps_engine: 'Google Maps + High-Precision Geodesic',
      server: 'Node.js Dev Server'
    }));
    return;
  }

  if (pathname === '/api/locations/search') {
    const q = (parsedUrl.query.q || '').trim().toLowerCase();
    const limit = parseInt(parsedUrl.query.limit || '8', 10);
    const results = LOCATIONS.filter(l =>
      l.name.toLowerCase().startsWith(q) ||
      l.name.toLowerCase().includes(q) ||
      l.keywords.includes(q)
    ).slice(0, limit);

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ query: q, count: results.length, results }));
    return;
  }

  if (pathname === '/api/routes/compare' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const parsed = JSON.parse(body || '{}');
        const src = (parsed.source || '').trim();
        const dst = (parsed.destination || '').trim();

        if (!src || !dst) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: "Both 'source' and 'destination' are required" }));
          return;
        }

        const data = computeRoute(src, dst);
        if (data) {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, data }));
        } else {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: `Could not resolve route between '${src}' and '${dst}'` }));
        }
      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  if (pathname === '/api/history') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ history: SEARCH_HISTORY }));
    return;
  }

  // Static File Serving
  if (pathname === '/' || pathname === '') pathname = '/index.html';
  let filePath = path.join(FRONTEND_DIR, pathname);

  // If file doesn't exist directly in frontend, check root or default to index.html
  if (!fs.existsSync(filePath)) {
    filePath = path.join(FRONTEND_DIR, 'index.html');
  }

  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('404 Not Found');
    } else {
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    }
  });
});

server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    const nextPort = (currentPort || PORT) + 1;
    currentPort = nextPort;
    console.log(`\n\x1b[33m⚠️ Port in use by an existing server instance.\x1b[0m`);
    console.log(`🔄 Automatically trying port \x1b[32m${nextPort}\x1b[0m...\n`);
    setTimeout(() => {
      server.listen(nextPort);
    }, 200);
    return;
  }
  console.error('Server error:', err);
});

server.on('listening', () => {
  const actualPort = server.address().port;
  const url = `http://localhost:${actualPort}`;
  console.log('\n' + '='.repeat(74));
  console.log('🚀 UNIFIED INTELLIGENT TRANSPORTATION SYSTEM (UITS)');
  console.log('Real GPS Distance + Real Transport Rates + Smart Route Recommendation');
  console.log(`📡 Local Web Dashboard: \x1b[32m${url}\x1b[0m`);
  console.log(`📡 API Health Check:    \x1b[36m${url}/api/health\x1b[0m`);
  console.log('='.repeat(74) + '\n');

  // Open default browser on Windows
  if (process.platform === 'win32') {
    exec(`start ${url}`);
  }
});

let currentPort = PORT;
server.listen(currentPort);
