"""
Unified Intelligent Transportation System (UITS)
Pricing & Fare Configuration Module
All transportation fare rules, base rates, minimum fares, and public transport slab matrices.
Easily configurable to adapt to changing transit authority notifications.
"""

# Configurable Road Transportation Rates (in Indian Rupees INR ₹)
ROAD_TRANSPORT_CONFIG = {
    "rapido_bike": {
        "name": "Rapido Bike",
        "category": "Road",
        "base_fare": 25.0,           # Includes first 1.5 KM
        "base_km": 1.5,
        "per_km_rate": 8.0,          # ₹8 per km after base km
        "min_fare": 25.0,
        "booking_fee": 3.0,
        "waiting_charge_per_min": 0.5,
        "avg_speed_city_kmh": 32.0,
        "avg_speed_highway_kmh": 45.0,
        "max_operational_km": 45.0,  # Bikes are for city commutes
        "convenience_score": 72.0,   # 1-100
        "availability_score": 94.0,  # 1-100
        "status_label": "Live Estimate"
    },
    "auto_rickshaw": {
        "name": "Auto Rickshaw",
        "category": "Road",
        "base_fare": 35.0,           # Includes first 1.8 KM (Tamil Nadu govt revised base)
        "base_km": 1.8,
        "per_km_rate": 15.0,         # ₹15 per km after base
        "min_fare": 35.0,
        "booking_fee": 0.0,
        "waiting_charge_per_min": 0.75,
        "avg_speed_city_kmh": 26.0,
        "avg_speed_highway_kmh": 35.0,
        "max_operational_km": 40.0,
        "convenience_score": 76.0,
        "availability_score": 95.0,
        "status_label": "Standard Rate"
    },
    "ola_mini": {
        "name": "Ola Mini Cab",
        "category": "Road",
        "base_fare": 50.0,           # Includes first 2.0 KM
        "base_km": 2.0,
        "per_km_rate": 14.0,         # ₹14/km in city
        "outstation_per_km": 12.0,   # ₹12/km for intercity (> 60 km)
        "min_fare": 90.0,
        "booking_fee": 15.0,
        "waiting_charge_per_min": 1.2,
        "avg_speed_city_kmh": 26.0,
        "avg_speed_highway_kmh": 68.0,
        "max_operational_km": 800.0,
        "convenience_score": 84.0,
        "availability_score": 92.0,
        "status_label": "Live Estimate"
    },
    "uber_go": {
        "name": "Uber Go",
        "category": "Road",
        "base_fare": 55.0,           # Includes first 2.0 KM
        "base_km": 2.0,
        "per_km_rate": 14.5,         # ₹14.50/km in city
        "outstation_per_km": 12.5,
        "min_fare": 95.0,
        "booking_fee": 16.0,
        "waiting_charge_per_min": 1.2,
        "avg_speed_city_kmh": 26.0,
        "avg_speed_highway_kmh": 68.0,
        "max_operational_km": 800.0,
        "convenience_score": 85.0,
        "availability_score": 93.0,
        "status_label": "Live Estimate"
    },
    "ola_prime": {
        "name": "Ola Prime Cab",
        "category": "Road",
        "base_fare": 75.0,           # Includes first 2.0 KM
        "base_km": 2.0,
        "per_km_rate": 17.0,
        "outstation_per_km": 14.5,
        "min_fare": 130.0,
        "booking_fee": 20.0,
        "waiting_charge_per_min": 1.5,
        "avg_speed_city_kmh": 28.0,
        "avg_speed_highway_kmh": 72.0,
        "max_operational_km": 1000.0,
        "convenience_score": 91.0,
        "availability_score": 89.0,
        "status_label": "Live Estimate"
    },
    "uber_premier": {
        "name": "Uber Premier",
        "category": "Road",
        "base_fare": 85.0,           # Includes first 2.0 KM
        "base_km": 2.0,
        "per_km_rate": 19.0,
        "outstation_per_km": 16.0,
        "min_fare": 150.0,
        "booking_fee": 22.0,
        "waiting_charge_per_min": 1.8,
        "avg_speed_city_kmh": 28.0,
        "avg_speed_highway_kmh": 74.0,
        "max_operational_km": 1000.0,
        "convenience_score": 94.0,
        "availability_score": 86.0,
        "status_label": "Live Estimate"
    },
    "electric_taxi": {
        "name": "Electric Taxi",
        "category": "Road",
        "base_fare": 60.0,           # Includes first 2.0 KM
        "base_km": 2.0,
        "per_km_rate": 15.0,         # Zero emissions, consistent pricing
        "outstation_per_km": 14.0,
        "min_fare": 100.0,
        "booking_fee": 10.0,
        "waiting_charge_per_min": 1.0,
        "avg_speed_city_kmh": 27.0,
        "avg_speed_highway_kmh": 68.0,
        "max_operational_km": 120.0, # EV battery range constraint
        "convenience_score": 90.0,
        "availability_score": 84.0,
        "status_label": "Eco Friendly"
    },
    "luxury_cab": {
        "name": "Luxury Cab",
        "category": "Road",
        "base_fare": 180.0,          # Includes first 3.0 KM
        "base_km": 3.0,
        "per_km_rate": 26.0,
        "outstation_per_km": 22.0,
        "min_fare": 350.0,
        "booking_fee": 35.0,
        "waiting_charge_per_min": 2.5,
        "avg_speed_city_kmh": 30.0,
        "avg_speed_highway_kmh": 78.0,
        "max_operational_km": 1000.0,
        "convenience_score": 98.0,
        "availability_score": 75.0,
        "status_label": "Executive"
    }
}

# Configurable Public Transportation Rates & Slabs
PUBLIC_TRANSPORT_CONFIG = {
    "govt_bus": {
        "name": "Government Bus",
        "category": "Public",
        "city_slabs": [
            (0.0, 2.0, 5.0),
            (2.0, 4.0, 9.0),
            (4.0, 7.0, 12.0),
            (7.0, 12.0, 15.0),
            (12.0, 18.0, 19.0),
            (18.0, 26.0, 23.0),
            (26.0, 35.0, 28.0),
            (35.0, 50.0, 35.0)
        ],
        "intercity_rate_per_km": 1.25, # TNSTC / SETC Deluxe Express
        "intercity_min_fare": 50.0,
        "avg_speed_city_kmh": 20.0,
        "avg_speed_highway_kmh": 55.0,
        "wait_and_boarding_min": 10.0,
        "convenience_score": 65.0,
        "availability_score": 96.0,
        "status_label": "MTC / TNSTC Verified"
    },
    "private_bus": {
        "name": "Private Bus",
        "category": "Public",
        "city_base_fare": 15.0,
        "city_rate_per_km": 2.2,
        "intercity_base_fare": 250.0,  # AC Sleeper / Semi-sleeper base
        "intercity_rate_per_km": 1.95,
        "intercity_min_fare": 300.0,
        "avg_speed_city_kmh": 22.0,
        "avg_speed_highway_kmh": 62.0,
        "wait_and_boarding_min": 15.0,
        "convenience_score": 83.0,
        "availability_score": 88.0,
        "status_label": "Omni / AC Sleeper"
    },
    "metro_train": {
        "name": "Metro Train",
        "category": "Public",
        "agency": "Chennai Metro Rail Limited (CMRL)",
        "slabs": [
            (0.0, 2.0, 10.0),
            (2.0, 4.0, 20.0),
            (4.0, 6.0, 30.0),
            (6.0, 9.0, 40.0),
            (9.0, 45.0, 50.0)
        ],
        "smartcard_discount_pct": 20.0, # 20% discount for smart card / QR users
        "avg_speed_kmh": 38.0,          # Punctual, uninterrupted grade-separated track
        "wait_and_boarding_min": 4.0,   # High frequency (every 5-7 mins)
        "convenience_score": 93.0,
        "availability_score": 97.0,
        "status_label": "CMRL Verified"
    },
    "suburban_train": {
        "name": "Suburban Train",
        "category": "Public",
        "agency": "Southern Railway Suburban EMU",
        "slabs": [
            (0.0, 10.0, 5.0),
            (10.0, 20.0, 10.0),
            (20.0, 45.0, 10.0),
            (45.0, 75.0, 15.0)
        ],
        "avg_speed_kmh": 36.0,
        "wait_and_boarding_min": 6.0,
        "convenience_score": 78.0,
        "availability_score": 92.0,
        "status_label": "SR EMU Verified"
    }
}

# Smart Score Weights (as specified in project requirements: Cost 45%, Time 35%, Convenience 10%, Availability 10%)
SMART_SCORE_WEIGHTS = {
    "cost": 0.45,
    "time": 0.35,
    "convenience": 0.10,
    "availability": 0.10
}
