"""
Travel Time Estimation Algorithm for UITS
Calculates realistic journey duration considering mode speeds,
traffic conditions, route classification, and boarding/wait times.
"""

from typing import Tuple

def estimate_travel_time(mode_code: str, distance_km: float, route_type: str, traffic_multiplier: float = 1.0) -> Tuple[int, float]:
    """
    Computes travel time in minutes based on transportation mode physics,
    traffic conditions, route type (urban vs highway), and station/dispatch delay.
    Returns (time_in_minutes, effective_speed_kmh).
    """
    # Speed and dispatch delay dictionary per mode
    SPEED_SPECS = {
        "rapido_bike": {
            "city_speed": 32.0,      # Bikes weave through traffic easily
            "highway_speed": 45.0,
            "wait_min": 3.0
        },
        "auto_rickshaw": {
            "city_speed": 26.0,
            "highway_speed": 35.0,
            "wait_min": 2.0
        },
        "ola_mini": {
            "city_speed": 25.0,
            "highway_speed": 68.0,
            "wait_min": 5.0
        },
        "uber_go": {
            "city_speed": 25.0,
            "highway_speed": 68.0,
            "wait_min": 5.0
        },
        "ola_prime": {
            "city_speed": 27.0,
            "highway_speed": 72.0,
            "wait_min": 5.0
        },
        "uber_premier": {
            "city_speed": 27.0,
            "highway_speed": 74.0,
            "wait_min": 6.0
        },
        "electric_taxi": {
            "city_speed": 26.0,
            "highway_speed": 65.0,
            "wait_min": 4.0
        },
        "luxury_cab": {
            "city_speed": 28.0,
            "highway_speed": 78.0,
            "wait_min": 7.0
        },
        "govt_bus": {
            "city_speed": 19.0,      # Frequent stops, boarding passengers
            "highway_speed": 55.0,   # SETC / Express buses
            "wait_min": 10.0
        },
        "private_bus": {
            "city_speed": 21.0,
            "highway_speed": 62.0,
            "wait_min": 15.0
        },
        "metro_train": {
            "city_speed": 38.0,      # High average speed, zero traffic interference
            "highway_speed": 38.0,
            "wait_min": 4.0          # Average headway interval
        },
        "suburban_train": {
            "city_speed": 36.0,
            "highway_speed": 44.0,
            "wait_min": 6.0
        }
    }

    spec = SPEED_SPECS.get(mode_code, {"city_speed": 25.0, "highway_speed": 60.0, "wait_min": 5.0})

    if route_type == "intercity":
        # Weight towards highway speed for the portion outside the city
        city_portion_km = min(15.0, distance_km * 0.1)
        highway_portion_km = distance_km - city_portion_km

        speed_city = spec["city_speed"] / traffic_multiplier
        speed_hwy = spec["highway_speed"]

        driving_hours = (city_portion_km / max(speed_city, 10.0)) + (highway_portion_km / max(speed_hwy, 20.0))
        effective_speed = distance_km / max(driving_hours, 0.01)
    else:
        # Local urban / suburban
        effective_speed = spec["city_speed"] / traffic_multiplier
        # Trains are immune to road traffic congestion
        if mode_code in ("metro_train", "suburban_train"):
            effective_speed = spec["city_speed"]
        driving_hours = distance_km / max(effective_speed, 10.0)

    # Total minutes = driving time + boarding/dispatch wait
    total_minutes = int(round((driving_hours * 60.0) + spec["wait_min"]))
    # Minimum realistic journey is at least 3 minutes
    total_minutes = max(3, total_minutes)

    return total_minutes, round(effective_speed, 1)
