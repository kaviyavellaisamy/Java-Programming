"""
Smart Score Algorithm for UITS
Multi-Criteria Decision Analysis (MCDA) using dynamic min-max normalization.

Weights:
- Travel Cost: 45% (Lower is better)
- Travel Time: 35% (Lower is better)
- Convenience & Comfort: 10% (Higher is better)
- Availability & Reliability: 10% (Higher is better)
"""

from typing import List, Tuple, Optional
from ..models.schemas import TransportOption, RecommendationCard

def calculate_smart_scores(options: List[TransportOption], source_name: str, dest_name: str, total_distance: float) -> Tuple[List[TransportOption], Optional[RecommendationCard]]:
    """
    Evaluates all transportation options dynamically using normalized MCDA.
    Automatically assigns smart_score to each available option and selects the optimal route.
    """
    available_options = [opt for opt in options if opt.is_available]

    if not available_options:
        return options, None

    # Extract costs and times for normalization
    costs = [opt.cost for opt in available_options]
    times = [opt.time_minutes for opt in available_options]

    min_cost = min(costs)
    max_cost = max(costs)
    min_time = min(times)
    max_time = max(times)

    # Cost spread and time spread
    cost_range = max_cost - min_cost if max_cost > min_cost else 1.0
    time_range = max_time - min_time if max_time > min_time else 1.0

    highest_score = -1.0
    best_option: Optional[TransportOption] = None

    for opt in available_options:
        # Inverted normalization: 100 for lowest cost/time, 0 for highest
        cost_score = 100.0 * (1.0 - (opt.cost - min_cost) / cost_range)
        time_score = 100.0 * (1.0 - (opt.time_minutes - min_time) / time_range)

        # Convenience & Availability scores are calibrated from 0 to 100
        conv_score = float(opt.breakdown.get("convenience_score", 80.0))
        avail_score = float(opt.breakdown.get("availability_score", 90.0))

        # Weighted Smart Score Formula (45% Cost, 35% Time, 10% Convenience, 10% Availability)
        smart_score = (
            0.45 * cost_score +
            0.35 * time_score +
            0.10 * conv_score +
            0.10 * avail_score
        )

        # Round to 1 decimal place
        opt.smart_score = round(smart_score, 1)

        # Store component scores in breakdown for transparency & academic presentation
        opt.breakdown["score_components"] = {
            "cost_score": round(cost_score, 1),
            "time_score": round(time_score, 1),
            "convenience_score": round(conv_score, 1),
            "availability_score": round(avail_score, 1)
        }

        if opt.smart_score > highest_score:
            highest_score = opt.smart_score
            best_option = opt

    # Mark the winner
    if best_option:
        best_option.is_recommended = True

    # Mark unavailable modes
    for opt in options:
        if not opt.is_available:
            opt.smart_score = 0.0
            opt.is_recommended = False

    # Create recommendation card
    recommendation = None
    if best_option:
        reasoning = f"{best_option.mode} achieved the highest Smart Score ({best_option.smart_score}/100) by offering an optimal balance of cost (₹{best_option.cost:.2f}), travel time ({best_option.time_minutes} min), and accessibility."
        recommendation = RecommendationCard(
            source_name=source_name,
            dest_name=dest_name,
            total_distance_km=round(total_distance, 2),
            best_mode=best_option.mode,
            estimated_time_minutes=best_option.time_minutes,
            estimated_cost=round(best_option.cost, 2),
            smart_score=best_option.smart_score,
            status="BEST OPTION",
            reasoning=reasoning
        )

    return options, recommendation
