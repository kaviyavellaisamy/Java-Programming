"""
Route Engine for UITS
Calculates geodesic and real road distance, tortuosity factors,
and generates route polyline waypoints.
"""

import math
from typing import Tuple, List

EARTH_RADIUS_KM = 6371.0088

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """
    Computes great-circle distance between two GPS coordinates using the Haversine formula.
    Returns distance in kilometers.
    """
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (math.sin(delta_phi / 2.0) ** 2 +
         math.cos(phi1) * math.cos(phi2) * (math.sin(delta_lambda / 2.0) ** 2))
    c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))

    return EARTH_RADIUS_KM * c

def calculate_road_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> Tuple[float, float, str]:
    """
    Calculates estimated actual road distance based on geodesic distance and urban/highway tortuosity models.
    Returns (road_distance_km, direct_distance_km, route_type)
    """
    direct_km = haversine_distance(lat1, lon1, lat2, lon2)

    if direct_km < 15.0:
        # Dense urban street grid (turns, intersections, flyovers)
        road_factor = 1.28
        route_type = "local_urban"
    elif direct_km < 45.0:
        # Suburban arterial roads / Ring roads
        road_factor = 1.22
        route_type = "local_suburban"
    else:
        # State & National Highways (NH48, NH44, GST Road, etc.)
        road_factor = 1.16
        route_type = "intercity"

    road_km = direct_km * road_factor
    return round(road_km, 2), round(direct_km, 2), route_type

def generate_interpolated_waypoints(lat1: float, lon1: float, lat2: float, lon2: float, num_points: int = 25) -> List[List[float]]:
    """
    Generates realistic road-like waypoint coordinates between two GPS points
    with natural curvature mimicking actual street and highway corridors.
    """
    points = []
    direct_km = haversine_distance(lat1, lon1, lat2, lon2)

    # Calculate perpendicular offset direction for realistic road curving
    d_lat = lat2 - lat1
    d_lon = lon2 - lon1

    # Number of steps proportional to distance
    steps = max(15, min(60, int(direct_km * 2))) if direct_km < 40 else max(30, min(100, int(direct_km / 4)))

    for i in range(steps + 1):
        t = i / float(steps)
        # Base linear interpolation
        base_lat = lat1 + t * d_lat
        base_lon = lon1 + t * d_lon

        # Add natural road curvature sinusoidal variation
        curve_factor = math.sin(t * math.pi) * 0.003 if direct_km < 25 else math.sin(t * math.pi) * 0.015

        # Alternate gentle sway for realistic road network feel
        perp_lat = -d_lon * 0.05 * math.sin(t * math.pi * 2.0) * (0.002 if direct_km < 25 else 0.008)
        perp_lon = d_lat * 0.05 * math.sin(t * math.pi * 2.0) * (0.002 if direct_km < 25 else 0.008)

        curved_lat = base_lat + perp_lat
        curved_lon = base_lon + perp_lon

        points.append([round(curved_lat, 6), round(curved_lon, 6)])

    # Ensure exact endpoints
    points[0] = [lat1, lon1]
    points[-1] = [lat2, lon2]

    return points
