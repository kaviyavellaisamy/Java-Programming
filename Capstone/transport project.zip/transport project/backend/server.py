"""
High-Performance, Zero-Dependency Server for UITS.
Uses Python standard library http.server with ThreadingHTTPServer.
Handles:
- Full REST API with JSON responses and CORS support
- Serving static frontend files (HTML5, React JS, CSS, images)
"""

import os
import sys
import json
import mimetypes
from urllib.parse import urlparse, parse_qs
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler

# Add root directory to python path for imports
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from backend.routes.api import handle_api_request

FRONTEND_DIR = os.path.join(ROOT_DIR, "frontend")

class UITSRequestHandler(BaseHTTPRequestHandler):
    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")

    def do_OPTIONS(self):
        self.send_response(204)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        # Route API requests
        if path.startswith("/api/"):
            status_code, response_data = handle_api_request("GET", path, query, None)
            self.send_response(status_code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps(response_data).encode("utf-8"))
            return

        # Serve static frontend files
        if path == "/" or path == "":
            file_path = os.path.join(FRONTEND_DIR, "index.html")
        else:
            rel_path = path.lstrip("/")
            file_path = os.path.join(FRONTEND_DIR, rel_path)

        # Normalize and ensure file stays inside FRONTEND_DIR
        file_path = os.path.abspath(file_path)
        if not file_path.startswith(FRONTEND_DIR) or not os.path.exists(file_path) or os.path.isdir(file_path):
            # Fallback to index.html for SPA routing
            file_path = os.path.join(FRONTEND_DIR, "index.html")

        if os.path.exists(file_path):
            mime_type, _ = mimetypes.guess_type(file_path)
            if not mime_type:
                mime_type = "application/octet-stream"
            if file_path.endswith(".js") or file_path.endswith(".jsx"):
                mime_type = "application/javascript"

            self.send_response(200)
            self.send_header("Content-Type", f"{mime_type}; charset=utf-8")
            self._send_cors_headers()
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            with open(file_path, "rb") as f:
                self.wfile.write(f.read())
        else:
            self.send_response(404)
            self.send_header("Content-Type", "text/plain")
            self.end_headers()
            self.wfile.write(b"404 Not Found")

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        content_length = int(self.headers.get("Content-Length", 0))
        post_data = self.rfile.read(content_length)

        body_data = None
        if post_data:
            try:
                body_data = json.loads(post_data.decode("utf-8"))
            except Exception:
                body_data = None

        if path.startswith("/api/"):
            status_code, response_data = handle_api_request("POST", path, query, body_data)
            self.send_response(status_code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self._send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps(response_data).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()

    def log_message(self, format, *args):
        # Clean logging format
        sys.stderr.write(f"[{self.log_date_time_string()}] {format % args}\n")

def run_server(port: int = 5000, host: str = "0.0.0.0"):
    server_address = (host, port)
    httpd = ThreadingHTTPServer(server_address, UITSRequestHandler)
    print("=" * 70)
    print("🚀 UNIFIED INTELLIGENT TRANSPORTATION SYSTEM (UITS) SERVER STARTED")
    print(f"📡 Local Web Dashboard: http://localhost:{port}")
    print(f"📡 API Health Check:    http://localhost:{port}/api/health")
    print("=" * 70)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping UITS server...")
        httpd.server_close()

if __name__ == "__main__":
    port = 5000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    run_server(port=port)
