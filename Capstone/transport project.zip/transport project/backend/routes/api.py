"""
API handler logic for UITS.
Provides RESTful endpoints for geocoding, route comparison, smart recommendation, and history.
Can be mounted on Flask, FastAPI, or executed by our zero-dependency HTTP server.
"""

import json
from typing import Dict, Any, Tuple, Optional
from ..services.geocoding_service import search_locations, geocode_location, get_alternative_suggestions
from ..services.routing_service import compute_route_comparison
import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "database", "uits.db")

def handle_api_request(method: str, path: str, query_params: Dict[str, str], body_data: Optional[Dict[str, Any]]) -> Tuple[int, Dict[str, Any]]:
    """
    Unified router that processes API calls and returns (status_code, json_dict).
    """
    # 1. Health check
    if path == "/api/health":
        return 200, {
            "status": "healthy",
            "system": "Unified Intelligent Transportation System (UITS)",
            "version": "2.0.0",
            "gps_engine": "Google Maps + High-Precision GPS",
            "database": "SQLite 3"
        }

    # 2. Location Autocomplete Search
    elif path == "/api/locations/search":
        q = query_params.get("q", "").strip()
        limit = int(query_params.get("limit", "8"))
        if not q:
            return 200, {"query": "", "results": []}
        results = search_locations(q, limit=limit)
        return 200, {"query": q, "count": len(results), "results": results}

    # 3. Geocode Single Location
    elif path == "/api/locations/geocode":
        q = query_params.get("q", "").strip()
        if not q:
            return 400, {"error": "Query parameter 'q' is required"}
        loc = geocode_location(q)
        if loc:
            return 200, {"location": loc}
        else:
            alternatives = get_alternative_suggestions(q, limit=5)
            return 404, {
                "error": f"Location '{q}' not found",
                "suggestions": alternatives
            }

    # 4. Route Comparison and Smart Score Recommendation
    elif path == "/api/routes/compare":
        if method != "POST":
            return 405, {"error": "Method not allowed. Use POST."}

        if not body_data:
            return 400, {"error": "Request body JSON is required"}

        source = body_data.get("source", "").strip()
        destination = body_data.get("destination", "").strip()

        if not source or not destination:
            return 400, {"error": "Both 'source' and 'destination' locations are required"}

        if source.lower() == destination.lower():
            return 400, {"error": "Source and destination cannot be identical"}

        result = compute_route_comparison(source, destination)
        if not result:
            src_check = geocode_location(source)
            dst_check = geocode_location(destination)
            missing = []
            if not src_check:
                missing.append(f"Source location '{source}' could not be identified")
            if not dst_check:
                missing.append(f"Destination location '{destination}' could not be identified")

            return 404, {
                "error": "Failed to calculate route",
                "details": missing,
                "source_suggestions": get_alternative_suggestions(source) if not src_check else [],
                "destination_suggestions": get_alternative_suggestions(destination) if not dst_check else []
            }

        return 200, {
            "success": True,
            "data": result
        }

    # 5. Route Search History
    elif path == "/api/history":
        try:
            conn = sqlite3.connect(DB_PATH)
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, source_name, dest_name, distance_km, best_mode, best_cost, best_time, smart_score, searched_at
                FROM route_history
                ORDER BY searched_at DESC
                LIMIT 10
            """)
            rows = cursor.fetchall()
            conn.close()
            history = [
                {
                    "id": r[0],
                    "source": r[1],
                    "destination": r[2],
                    "distance_km": r[3],
                    "best_mode": r[4],
                    "cost": r[5],
                    "time": r[6],
                    "smart_score": r[7],
                    "timestamp": r[8]
                }
                for r in rows
            ]
            return 200, {"history": history}
        except Exception as e:
            return 500, {"error": str(e)}

    # 6. Default 404
    return 404, {"error": f"Endpoint '{path}' not found"}
