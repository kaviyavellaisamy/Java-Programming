"""Routes package."""
from .api import handle_api_request
