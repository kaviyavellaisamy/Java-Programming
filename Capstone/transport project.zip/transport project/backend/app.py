"""
Flask Application Wrapper for UITS.
Provides standard Flask routes while offering seamless zero-dependency fallback.
"""

import os
import sys

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from backend.routes.api import handle_api_request

try:
    from flask import Flask, request, jsonify, send_from_directory
    from flask_cors import CORS

    app = Flask(__name__, static_folder="../frontend", static_url_path="")
    CORS(app)

    @app.route("/api/<path:subpath>", methods=["GET", "POST", "OPTIONS"])
    def api_catchall(subpath):
        if request.method == "OPTIONS":
            return "", 204

        full_path = "/api/" + subpath
        query = {k: v for k, v in request.args.items()}
        body = request.get_json(silent=True)
        status_code, data = handle_api_request(request.method, full_path, query, body)
        return jsonify(data), status_code

    @app.route("/", defaults={"path": ""})
    @app.route("/<path:path>")
    def serve_frontend(path):
        if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
            return send_from_directory(app.static_folder, path)
        return send_from_directory(app.static_folder, "index.html")

    def run_flask(port=5000):
        print(f"🚀 Starting UITS via Flask on http://localhost:{port}")
        app.run(host="0.0.0.0", port=port, debug=False)

except ImportError:
    # Flask is not installed; seamlessly fallback to standard library server
    from backend.server import run_server as run_flask

if __name__ == "__main__":
    port = 5000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass
    run_flask(port=port)
