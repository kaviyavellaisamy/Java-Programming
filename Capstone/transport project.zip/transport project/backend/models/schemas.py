"""
Data models and schemas for UITS application.
"""

from dataclasses import dataclass, asdict, field
from typing import List, Optional, Dict, Any

@dataclass
class LocationPoint:
    name: str
    display_name: str
    latitude: float
    longitude: float
    category: str = "location"
    city: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class TransportOption:
    mode: str                         # Transportation name
    code: str                         # Internal code
    category: str                     # Road or Public
    rate_per_km: float                # Rate (₹/KM)
    distance_km: float                # Distance (KM)
    time_minutes: int                 # Time (Minutes)
    cost: float                       # Cost (₹)
    smart_score: float                # Calculated Smart Score
    status: str                       # Availability / data status
    is_available: bool = True
    is_recommended: bool = False
    breakdown: Dict[str, Any] = field(default_factory=dict)
    icon: str = "car"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class RecommendationCard:
    source_name: str
    dest_name: str
    total_distance_km: float
    best_mode: str
    estimated_time_minutes: int
    estimated_cost: float
    smart_score: float
    status: str = "BEST OPTION"
    reasoning: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class RouteSummary:
    source: LocationPoint
    destination: LocationPoint
    distance_km: float
    direct_distance_km: float
    route_type: str                  # local_urban, local_suburban, intercity
    coordinates: List[List[float]]   # [[lat, lon], ...]
    options: List[TransportOption]
    recommendation: Optional[RecommendationCard]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source": self.source.to_dict(),
            "destination": self.destination.to_dict(),
            "distance_km": self.distance_km,
            "direct_distance_km": self.direct_distance_km,
            "route_type": self.route_type,
            "coordinates": self.coordinates,
            "options": [opt.to_dict() for opt in self.options],
            "recommendation": self.recommendation.to_dict() if self.recommendation else None
        }
