"""
High-Speed Transit Feasibility and Network Service for UITS.
Preloads transit station coordinates into memory for instant (< 0.1ms) proximity checks.
"""

import sqlite3
import os
from typing import Dict, Any, Tuple, Optional, List
from ..algorithms.route_engine import haversine_distance

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "database", "uits.db")

_PRELOADED_METRO: List[Tuple[str, str, float, float]] = []
_PRELOADED_SUBURBAN: List[Tuple[str, str, float, float]] = []

def preload_stations():
    global _PRELOADED_METRO, _PRELOADED_SUBURBAN
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT station_name, line, latitude, longitude FROM metro_stations")
        _PRELOADED_METRO = cursor.fetchall()
        cursor.execute("SELECT station_name, line, latitude, longitude FROM suburban_stations")
        _PRELOADED_SUBURBAN = cursor.fetchall()
        conn.close()
    except Exception as e:
        print(f"Notice: Transit stations preload notice: {e}")

preload_stations()

def find_nearest_metro_station(lat: float, lon: float) -> Tuple[Optional[str], Optional[str], float]:
    """Instant in-memory lookup of nearest metro station."""
    if not _PRELOADED_METRO:
        preload_stations()

    closest_station = None
    closest_line = None
    min_dist = float("inf")

    for name, line, s_lat, s_lon in _PRELOADED_METRO:
        dist = haversine_distance(lat, lon, s_lat, s_lon)
        if dist < min_dist:
            min_dist = dist
            closest_station = name
            closest_line = line

    return closest_station, closest_line, round(min_dist, 2)

def find_nearest_suburban_station(lat: float, lon: float) -> Tuple[Optional[str], Optional[str], float]:
    """Instant in-memory lookup of nearest suburban train station."""
    if not _PRELOADED_SUBURBAN:
        preload_stations()

    closest_station = None
    closest_line = None
    min_dist = float("inf")

    for name, line, s_lat, s_lon in _PRELOADED_SUBURBAN:
        dist = haversine_distance(lat, lon, s_lat, s_lon)
        if dist < min_dist:
            min_dist = dist
            closest_station = name
            closest_line = line

    return closest_station, closest_line, round(min_dist, 2)

def evaluate_mode_availability(mode_code: str, distance_km: float, route_type: str,
                               source_lat: float, source_lon: float,
                               dest_lat: float, dest_lon: float) -> Tuple[bool, str, Dict[str, Any]]:
    """Evaluates transport mode availability with sub-millisecond execution."""
    meta: Dict[str, Any] = {}

    # 1. Metro Train
    if mode_code == "metro_train":
        if distance_km > 45.0 or route_type == "intercity":
            return False, "Unavailable (No Intercity Metro)", meta

        src_stn, src_line, src_dist = find_nearest_metro_station(source_lat, source_lon)
        dst_stn, dst_line, dst_dist = find_nearest_metro_station(dest_lat, dest_lon)

        if src_stn and dst_stn and src_dist <= 4.0 and dst_dist <= 4.0:
            line_info = src_line if src_line == dst_line else f"{src_line} ➔ {dst_line} Interchange"
            status = f"Available ({line_info})"
            meta = {
                "source_station": src_stn,
                "dest_station": dst_stn,
                "src_station_distance_km": src_dist,
                "dst_station_distance_km": dst_dist,
                "line": line_info
            }
            return True, status, meta
        else:
            return False, "Unavailable (Outside Metro Catchment)", meta

    # 2. Suburban Train
    elif mode_code == "suburban_train":
        if distance_km > 75.0 or route_type == "intercity":
            return False, "Unavailable (No Suburban Line)", meta

        src_sub, src_line, src_dist = find_nearest_suburban_station(source_lat, source_lon)
        dst_sub, dst_line, dst_dist = find_nearest_suburban_station(dest_lat, dest_lon)

        if src_sub and dst_sub and src_dist <= 4.5 and dst_dist <= 4.5:
            status = f"Available ({src_line})"
            meta = {
                "source_station": src_sub,
                "dest_station": dst_sub,
                "line": src_line
            }
            return True, status, meta
        else:
            return False, "Unavailable (No Rail Connectivity)", meta

    # 3. Rapido Bike
    elif mode_code == "rapido_bike":
        if distance_km > 45.0:
            return False, "Unavailable (> 45 KM City Limit)", meta
        return True, "Available", meta

    # 4. Auto Rickshaw
    elif mode_code == "auto_rickshaw":
        if distance_km > 40.0:
            return False, "Unavailable (> 40 KM Limit)", meta
        return True, "Available", meta

    # 5. Electric Taxi
    elif mode_code == "electric_taxi":
        if distance_km > 120.0:
            return False, "Unavailable (Exceeds EV Range)", meta
        return True, "Available (Eco EV)", meta

    # 6. Government Bus
    elif mode_code == "govt_bus":
        if route_type == "intercity":
            return True, "Available (TNSTC / SETC)", meta
        return True, "Available (MTC City Bus)", meta

    # 7. Private Bus
    elif mode_code == "private_bus":
        if route_type == "intercity":
            return True, "Available (Omni / AC Sleeper)", meta
        return True, "Available (Private Feeder)", meta

    # 8. Cabs (Ola, Uber, Luxury)
    else:
        if route_type == "intercity":
            return True, "Available (Outstation)", meta
        return True, "Available", meta
