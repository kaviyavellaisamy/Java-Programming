"""
High-Speed Geocoding and Location Search Service for UITS.
Optimized with in-memory caching, indexing, and sub-millisecond lookup.
"""

import sqlite3
import os
import urllib.request
import urllib.parse
import json
from typing import List, Dict, Any, Optional
from functools import lru_cache

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "database", "uits.db")

# In-Memory Cache and Preloaded Gazetteers for ultra-fast response (< 1ms)
_MEMORY_LOCATIONS: List[Dict[str, Any]] = []
_NAME_TO_LOCATION: Dict[str, Dict[str, Any]] = {}
_SEARCH_CACHE: Dict[str, List[Dict[str, Any]]] = {}

def preload_locations():
    """Preloads all locations from SQLite into memory for sub-millisecond lookups."""
    global _MEMORY_LOCATIONS, _NAME_TO_LOCATION
    _MEMORY_LOCATIONS = []
    _NAME_TO_LOCATION = {}
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT name, display_name, category, city, latitude, longitude, keywords FROM locations")
        rows = cursor.fetchall()
        conn.close()

        for r in rows:
            item = {
                "name": r[0],
                "display_name": r[1],
                "category": r[2],
                "city": r[3],
                "latitude": r[4],
                "longitude": r[5],
                "keywords": (r[6] or "").lower(),
                "source": "verified_local"
            }
            _MEMORY_LOCATIONS.append(item)
            _NAME_TO_LOCATION[r[0].lower()] = item
            # Also index common variations (e.g. "koyambedu" -> "koyambedu cmbt")
            clean_name = r[0].lower().replace(".", "").replace("-", " ")
            _NAME_TO_LOCATION[clean_name] = item
    except Exception as e:
        print(f"Notice: In-memory location preloading warning: {e}")

# Preload on module load
preload_locations()

def search_locations(query: str, limit: int = 8) -> List[Dict[str, Any]]:
    """
    Sub-millisecond location autocomplete search.
    Checks memory cache first, then in-memory gazetteer, then external Nominatim only if no local match.
    """
    query_clean = query.strip().lower()
    if not query_clean or len(query_clean) < 2:
        return []

    # Check cache
    cache_key = f"{query_clean}_{limit}"
    if cache_key in _SEARCH_CACHE:
        return _SEARCH_CACHE[cache_key]

    results: List[Dict[str, Any]] = []
    seen = set()

    # 1. High-speed in-memory scan (takes < 0.1ms for hundreds of locations)
    exact_matches = []
    prefix_matches = []
    keyword_matches = []

    for loc in _MEMORY_LOCATIONS:
        loc_name = loc["name"].lower()
        if loc_name == query_clean:
            exact_matches.append(loc)
            seen.add(loc_name)
        elif loc_name.startswith(query_clean):
            prefix_matches.append(loc)
            seen.add(loc_name)
        elif query_clean in loc_name or query_clean in loc["keywords"] or query_clean in loc["display_name"].lower():
            if loc_name not in seen:
                keyword_matches.append(loc)
                seen.add(loc_name)

    results = exact_matches + prefix_matches + keyword_matches

    # If we found enough results from our verified gazetteer, return IMMEDIATELY! (Zero network lag)
    if len(results) >= 3 or len(results) >= limit:
        final_res = results[:limit]
        _SEARCH_CACHE[cache_key] = final_res
        return final_res

    # 2. If no or few local results, try Nominatim with a fast 1-second timeout
    try:
        encoded_q = urllib.parse.quote(query_clean + (", Tamil Nadu, India" if "india" not in query_clean else ""))
        url = f"https://nominatim.openstreetmap.org/search?q={encoded_q}&format=json&limit={limit - len(results)}"
        req = urllib.request.Request(
            url,
            headers={"User-Agent": "UITS-IntelligentTransport-System/2.0 (student.uits@project.edu)"}
        )
        with urllib.request.urlopen(req, timeout=1.0) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            for item in data:
                disp = item.get("display_name", "")
                short_name = disp.split(",")[0]
                if short_name.lower() not in seen:
                    seen.add(short_name.lower())
                    results.append({
                        "name": short_name,
                        "display_name": disp,
                        "category": item.get("type", "landmark"),
                        "city": "Tamil Nadu",
                        "latitude": float(item["lat"]),
                        "longitude": float(item["lon"]),
                        "source": "osm_nominatim"
                    })
    except Exception:
        pass

    final_res = results[:limit]
    _SEARCH_CACHE[cache_key] = final_res
    return final_res

@lru_cache(maxsize=1024)
def geocode_location(location_str: str) -> Optional[Dict[str, Any]]:
    """
    Sub-millisecond exact geocoding with LRU memory caching.
    """
    clean_str = location_str.strip().lower()
    if not clean_str:
        return None

    # 1. Instant dictionary lookup (< 0.01 ms)
    if clean_str in _NAME_TO_LOCATION:
        return _NAME_TO_LOCATION[clean_str]

    clean_var = clean_str.replace(".", "").replace("-", " ")
    if clean_var in _NAME_TO_LOCATION:
        return _NAME_TO_LOCATION[clean_var]

    # 2. Partial search
    matches = search_locations(location_str, limit=5)
    if matches:
        return matches[0]

    return None

def get_alternative_suggestions(query: str, limit: int = 5) -> List[Dict[str, Any]]:
    return search_locations(query, limit=limit)
