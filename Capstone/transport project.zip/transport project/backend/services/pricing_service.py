"""
Pricing and Fare Calculation Service for UITS.
Implements specific, realistic fare models for each of the 12 transportation options.
Uses official CMRL slabs, Southern Railway EMU slabs, MTC stage slabs, and ride-hailing tariff models.
"""

from typing import Dict, Any, Tuple
from ..config.pricing_config import ROAD_TRANSPORT_CONFIG, PUBLIC_TRANSPORT_CONFIG

def calculate_mode_fare(mode_code: str, distance_km: float, route_type: str) -> Tuple[float, float, Dict[str, Any]]:
    """
    Computes (total_cost_in_rupees, rate_per_km, fare_breakdown_dict).
    """
    breakdown = {}

    # 1. Road Transportation Modes
    if mode_code in ROAD_TRANSPORT_CONFIG:
        cfg = ROAD_TRANSPORT_CONFIG[mode_code]
        base_fare = cfg["base_fare"]
        base_km = cfg["base_km"]
        min_fare = cfg["min_fare"]
        booking_fee = cfg.get("booking_fee", 0.0)

        # Distinguish between city and highway/outstation per-km rates
        if route_type == "intercity" and "outstation_per_km" in cfg:
            per_km = cfg["outstation_per_km"]
        else:
            per_km = cfg["per_km_rate"]

        # Formula: Base Fare covers first base_km, additional km charged at per_km rate
        if distance_km <= base_km:
            distance_cost = 0.0
        else:
            distance_cost = (distance_km - base_km) * per_km

        subtotal = base_fare + distance_cost + booking_fee
        total_cost = max(min_fare, subtotal)

        # Effective Rate per KM for the comparison table (or official rate)
        displayed_rate = per_km

        breakdown = {
            "base_fare": base_fare,
            "base_km": base_km,
            "per_km_rate": per_km,
            "booking_fee": booking_fee,
            "min_fare": min_fare,
            "pricing_type": "Road Tariff Formula",
            "convenience_score": cfg["convenience_score"],
            "availability_score": cfg["availability_score"]
        }

        return round(total_cost, 2), round(displayed_rate, 2), breakdown

    # 2. Public Transportation Modes
    elif mode_code in PUBLIC_TRANSPORT_CONFIG:
        cfg = PUBLIC_TRANSPORT_CONFIG[mode_code]

        if mode_code == "metro_train":
            # CMRL Tiered Fare Slab:
            # 0-2 km: ₹10 | 2-4 km: ₹20 | 4-6 km: ₹30 | 6-9 km: ₹40 | >9 km: ₹50
            slabs = cfg["slabs"]
            cost = 10.0
            for min_k, max_k, fare in slabs:
                if min_k <= distance_km <= max_k:
                    cost = fare
                    break
            else:
                cost = 50.0  # Max CMRL single token fare

            displayed_rate = round(cost / max(distance_km, 1.0), 2)
            breakdown = {
                "agency": cfg.get("agency", "CMRL"),
                "fare_model": "Official CMRL Fare Slabs",
                "smartcard_discount_applicable": True,
                "convenience_score": cfg["convenience_score"],
                "availability_score": cfg["availability_score"]
            }
            return round(cost, 2), displayed_rate, breakdown

        elif mode_code == "suburban_train":
            # Southern Railway EMU Fare Slabs:
            # 0-10 km: ₹5 | 11-20 km: ₹10 | 21-45 km: ₹10 | 46-75 km: ₹15
            slabs = cfg["slabs"]
            cost = 5.0
            for min_k, max_k, fare in slabs:
                if min_k <= distance_km <= max_k:
                    cost = fare
                    break
            else:
                cost = 15.0

            displayed_rate = round(cost / max(distance_km, 1.0), 2)
            breakdown = {
                "agency": cfg.get("agency", "Southern Railway"),
                "fare_model": "Official Southern Railway EMU Slabs",
                "convenience_score": cfg["convenience_score"],
                "availability_score": cfg["availability_score"]
            }
            return round(cost, 2), displayed_rate, breakdown

        elif mode_code == "govt_bus":
            if route_type == "intercity":
                # Intercity TNSTC / SETC Deluxe Express
                rate = cfg["intercity_rate_per_km"]
                cost = max(cfg["intercity_min_fare"], distance_km * rate)
                displayed_rate = rate
                model_name = "TNSTC / SETC Intercity Express Fare"
            else:
                # MTC City Stage Fares
                slabs = cfg["city_slabs"]
                cost = 5.0
                for min_k, max_k, fare in slabs:
                    if min_k <= distance_km <= max_k:
                        cost = fare
                        break
                else:
                    cost = 35.0
                displayed_rate = round(cost / max(distance_km, 1.0), 2)
                model_name = "MTC Chennai City Stage Slabs"

            breakdown = {
                "fare_model": model_name,
                "convenience_score": cfg["convenience_score"],
                "availability_score": cfg["availability_score"]
            }
            return round(cost, 2), displayed_rate, breakdown

        elif mode_code == "private_bus":
            if route_type == "intercity":
                rate = cfg["intercity_rate_per_km"]
                cost = max(cfg["intercity_min_fare"], cfg["intercity_base_fare"] + (distance_km * rate))
                displayed_rate = rate
                model_name = "Private Omni AC / Semi-Sleeper"
            else:
                base = cfg["city_base_fare"]
                rate = cfg["city_rate_per_km"]
                cost = base + (distance_km * rate)
                displayed_rate = rate
                model_name = "Private City Feeder / Mini-Bus"

            breakdown = {
                "fare_model": model_name,
                "convenience_score": cfg["convenience_score"],
                "availability_score": cfg["availability_score"]
            }
            return round(cost, 2), displayed_rate, breakdown

    # Default fallback
    return round(distance_km * 12.0, 2), 12.0, {}
