"""
Database initialization and seeding for Unified Intelligent Transportation System (UITS).
Stores locations, GPS coordinates, transport modes, fare rules, and transit networks.
"""

import sqlite3
import os
import json

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uits.db")

def init_database():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()

    # 1. Locations Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS locations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        display_name TEXT NOT NULL,
        category TEXT NOT NULL, -- neighborhood, landmark, metro_station, railway_station, bus_terminal, airport, city
        city TEXT NOT NULL,
        state TEXT DEFAULT 'Tamil Nadu',
        latitude REAL NOT NULL,
        longitude REAL NOT NULL,
        keywords TEXT
    )
    """)

    # 2. Transport Modes Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS transport_modes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        category TEXT NOT NULL, -- Road, Public
        base_fare REAL NOT NULL,
        per_km_rate REAL NOT NULL,
        min_fare REAL NOT NULL,
        waiting_charge_per_min REAL DEFAULT 0.0,
        avg_speed_city REAL NOT NULL,
        avg_speed_highway REAL NOT NULL,
        convenience_score REAL NOT NULL, -- 0-100
        availability_score REAL NOT NULL, -- 0-100
        min_distance_km REAL DEFAULT 0.5,
        max_distance_km REAL DEFAULT 1000.0,
        pricing_model TEXT NOT NULL, -- 'linear', 'slab', 'tiered'
        icon TEXT NOT NULL,
        description TEXT
    )
    """)

    # 3. Fare Slabs Table (for public transport & special rules)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS fare_slabs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mode_code TEXT NOT NULL,
        min_km REAL NOT NULL,
        max_km REAL NOT NULL,
        fare REAL NOT NULL,
        FOREIGN KEY (mode_code) REFERENCES transport_modes (code)
    )
    """)

    # 4. Metro Stations Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS metro_stations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_name TEXT NOT NULL,
        line TEXT NOT NULL, -- Green Line, Blue Line, Inter-corridor
        order_index INTEGER NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL
    )
    """)

    # 5. Suburban Train Stations Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS suburban_stations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        station_name TEXT NOT NULL,
        line TEXT NOT NULL, -- South Line (Beach-Tambaram), West Line (Central-Arakkonam), North Line, MRTS (Beach-Velachery)
        order_index INTEGER NOT NULL,
        latitude REAL NOT NULL,
        longitude REAL NOT NULL
    )
    """)

    # 6. Route History Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS route_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_name TEXT NOT NULL,
        dest_name TEXT NOT NULL,
        source_lat REAL NOT NULL,
        source_lon REAL NOT NULL,
        dest_lat REAL NOT NULL,
        dest_lon REAL NOT NULL,
        distance_km REAL NOT NULL,
        best_mode TEXT NOT NULL,
        best_cost REAL NOT NULL,
        best_time REAL NOT NULL,
        smart_score REAL NOT NULL,
        searched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)

    # Clear existing seed data to ensure fresh up-to-date entries
    cursor.execute("DELETE FROM locations")
    cursor.execute("DELETE FROM transport_modes")
    cursor.execute("DELETE FROM fare_slabs")
    cursor.execute("DELETE FROM metro_stations")
    cursor.execute("DELETE FROM suburban_stations")

    # Seed Transport Modes (12 modes specified in requirements)
    modes = [
        # Road Transportation (8 modes)
        ("rapido_bike", "Rapido Bike", "Road", 25.0, 8.0, 25.0, 0.0, 32.0, 45.0, 72.0, 94.0, 0.5, 45.0, "linear", "bike", "Fastest two-wheeler bike taxi for local city traffic"),
        ("auto_rickshaw", "Auto Rickshaw", "Road", 35.0, 15.0, 35.0, 0.5, 26.0, 35.0, 76.0, 95.0, 0.5, 40.0, "linear", "auto", "Convenient three-wheeler for short and medium local travel"),
        ("ola_mini", "Ola Mini Cab", "Road", 50.0, 14.0, 90.0, 1.2, 26.0, 68.0, 84.0, 92.0, 1.0, 800.0, "linear", "cab-mini", "Compact AC hatchback cab (Indica, WagonR, Swift)"),
        ("uber_go", "Uber Go", "Road", 55.0, 14.5, 95.0, 1.2, 26.0, 68.0, 85.0, 93.0, 1.0, 800.0, "linear", "cab-go", "Affordable everyday compact AC ride"),
        ("ola_prime", "Ola Prime Cab", "Road", 75.0, 17.0, 130.0, 1.5, 28.0, 72.0, 91.0, 89.0, 1.0, 1000.0, "linear", "cab-prime", "Top-rated sedan cab with extra legroom and free Wi-Fi"),
        ("uber_premier", "Uber Premier", "Road", 85.0, 19.0, 150.0, 1.8, 28.0, 74.0, 94.0, 86.0, 1.0, 1000.0, "linear", "cab-premier", "Premium sedans driven by top-rated partners"),
        ("electric_taxi", "Electric Taxi", "Road", 60.0, 15.0, 100.0, 1.0, 27.0, 68.0, 90.0, 84.0, 1.0, 120.0, "linear", "cab-ev", "Zero-emission, quiet eco-friendly EV cab (BluSmart/EV Fleet)"),
        ("luxury_cab", "Luxury Cab", "Road", 180.0, 26.0, 350.0, 2.5, 30.0, 78.0, 98.0, 75.0, 2.0, 1000.0, "linear", "cab-luxury", "Executive luxury SUV / Sedan (Innova Crysta, Camry, Mercedes)"),

        # Public Transportation (4 modes)
        ("govt_bus", "Government Bus", "Public", 5.0, 1.4, 5.0, 0.0, 20.0, 55.0, 65.0, 95.0, 1.0, 1000.0, "slab", "bus", "MTC City Ordinary/Express Bus and TNSTC/SETC Intercity State Transport"),
        ("private_bus", "Private Bus", "Public", 20.0, 2.2, 30.0, 0.0, 22.0, 62.0, 82.0, 88.0, 3.0, 1000.0, "linear", "bus-private", "Private omni coach, AC Sleeper / Semi-sleeper intercity express"),
        ("metro_train", "Metro Train", "Public", 10.0, 3.5, 10.0, 0.0, 38.0, 38.0, 93.0, 97.0, 1.0, 45.0, "slab", "metro", "Chennai Metro Rail Limited (CMRL) Green and Blue Lines"),
        ("suburban_train", "Suburban Train", "Public", 5.0, 0.35, 5.0, 0.0, 36.0, 45.0, 78.0, 92.0, 2.0, 75.0, "slab", "train", "Southern Railway Suburban EMU local train network")
    ]

    cursor.executemany("""
    INSERT INTO transport_modes (
        code, name, category, base_fare, per_km_rate, min_fare, waiting_charge_per_min,
        avg_speed_city, avg_speed_highway, convenience_score, availability_score,
        min_distance_km, max_distance_km, pricing_model, icon, description
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, modes)

    # Seed Fare Slabs for Metro Train (CMRL Official Fare Slabs)
    # 0-2 km: Rs 10 | 2-4 km: Rs 20 | 4-6 km: Rs 30 | 6-9 km: Rs 40 | >9 km: Rs 50
    metro_slabs = [
        ("metro_train", 0.0, 2.0, 10.0),
        ("metro_train", 2.0, 4.0, 20.0),
        ("metro_train", 4.0, 6.0, 30.0),
        ("metro_train", 6.0, 9.0, 40.0),
        ("metro_train", 9.0, 100.0, 50.0)
    ]
    cursor.executemany("INSERT INTO fare_slabs (mode_code, min_km, max_km, fare) VALUES (?, ?, ?, ?)", metro_slabs)

    # Seed Fare Slabs for Suburban Train (Southern Railway Official EMU Slabs)
    # 1-10 km: Rs 5 | 11-20 km: Rs 10 | 21-45 km: Rs 10 | 46-75 km: Rs 15
    suburban_slabs = [
        ("suburban_train", 0.0, 10.0, 5.0),
        ("suburban_train", 10.0, 20.0, 10.0),
        ("suburban_train", 20.0, 45.0, 10.0),
        ("suburban_train", 45.0, 100.0, 15.0)
    ]
    cursor.executemany("INSERT INTO fare_slabs (mode_code, min_km, max_km, fare) VALUES (?, ?, ?, ?)", suburban_slabs)

    # Seed Fare Slabs for Government Bus (MTC Stage Fare for City <= 35 km)
    bus_slabs = [
        ("govt_bus", 0.0, 2.0, 5.0),
        ("govt_bus", 2.0, 4.0, 9.0),
        ("govt_bus", 4.0, 7.0, 12.0),
        ("govt_bus", 7.0, 12.0, 15.0),
        ("govt_bus", 12.0, 18.0, 19.0),
        ("govt_bus", 18.0, 26.0, 23.0),
        ("govt_bus", 26.0, 35.0, 28.0)
    ]
    cursor.executemany("INSERT INTO fare_slabs (mode_code, min_km, max_km, fare) VALUES (?, ?, ?, ?)", bus_slabs)

    # Seed Locations: Neighbourhoods, Landmarks, Metro & Railway Stations, Bus Terminals, Cities
    locations = [
        # Key Local Neighbourhoods & Landmarks in Chennai
        ("Shenoy Nagar", "Shenoy Nagar, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0784, 80.2285, "shenoy nagar park metro pillaivar koil thiru vi ka park"),
        ("Koyambedu CMBT", "Chennai Mofussil Bus Terminus (CMBT), Koyambedu, Chennai", "bus_terminal", "Chennai", 13.0694, 80.2078, "koyambedu cmbt bus stand mofussil metro market omni"),
        ("Koyambedu", "Koyambedu, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0694, 80.1948, "koyambedu junction market rohini silver screens"),
        ("Anna Nagar", "Anna Nagar, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0850, 80.2101, "anna nagar roundtana tower park shanthi colony 2nd avenue"),
        ("Anna Nagar East", "Anna Nagar East, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0872, 80.2215, "anna nagar east metro roundtana chintamani"),
        ("Anna Nagar West", "Anna Nagar West, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0906, 80.1983, "anna nagar west bus terminus millennium park"),
        ("T. Nagar", "Thyagaraya Nagar (T. Nagar), Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0418, 80.2341, "t nagar panagal park ranganathan street pondy bazaar shopping usman road"),
        ("Vadapalani", "Vadapalani, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0500, 80.2121, "vadapalani andavar temple nexus vijaya mall metro bus terminus"),
        ("Guindy", "Guindy, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0067, 80.2025, "guindy race course kathipara junction industrial estate metro railway station"),
        ("Ambattur", "Ambattur, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.1143, 80.1548, "ambattur industrial estate ot railway station ti cycles"),
        ("Kilpauk", "Kilpauk, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0788, 80.2417, "kilpauk medical college kmc metro poonamallee high road water works"),
        ("Mogappair", "Mogappair, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0863, 80.1762, "mogappair east west golden flats spartan school"),
        ("Porur", "Porur, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0382, 80.1565, "porur junction toll gate srmc ramachandra hospital lake"),
        ("Tambaram", "Tambaram, Chennai, Tamil Nadu", "neighborhood", "Chennai", 12.9249, 80.1000, "tambaram railway station bus stand mcc college west east national highway"),
        ("Velachery", "Velachery, Chennai, Tamil Nadu", "neighborhood", "Chennai", 12.9756, 80.2206, "velachery mrts railway station phoenix marketcity bypass road aquatic complex"),
        ("Adyar", "Adyar, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0012, 80.2565, "adyar signal lb road gandhi nagar cancer institute malar hospital"),
        ("Marina Beach", "Marina Beach, Chennai, Tamil Nadu", "landmark", "Chennai", 13.0500, 80.2824, "marina beach lighthouse triumph of labour kamarajar salai bay of bengal"),
        ("Chennai Central", "Puratchi Thalaivar Dr. M.G. Ramachandran Central Railway Station, Chennai", "railway_station", "Chennai", 13.0827, 80.2755, "chennai central mgr central railway station ripon building central metro park station"),
        ("Egmore", "Chennai Egmore Railway Station, Chennai", "railway_station", "Chennai", 13.0792, 80.2614, "chennai egmore railway station museum gothi surana hall metro"),
        ("Chennai Airport", "Chennai International Airport (MAA), Meenambakkam, Chennai", "airport", "Chennai", 12.9941, 80.1709, "chennai airport maa terminal domestic international meenambakkam metro"),
        ("Perambur", "Perambur, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.1112, 80.2422, "perambur railway station loco works icf carriage works"),
        ("Mylapore", "Mylapore, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0368, 80.2676, "mylapore kapaleeshwarar temple luz corner santhome kabali"),
        ("Nungambakkam", "Nungambakkam, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0595, 80.2425, "nungambakkam high road loyola college sterling road valluvar kottam"),
        ("Alwarpet", "Alwarpet, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0339, 80.2520, "alwarpet tt k road eldam's road park sheraton crown plaza"),
        ("Besant Nagar", "Besant Nagar, Chennai, Tamil Nadu", "neighborhood", "Chennai", 12.9982, 80.2666, "besant nagar elliot's beach velankanni church ashtalakshmi temple"),
        ("Saidapet", "Saidapet, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0213, 80.2231, "saidapet court metro railway station anna salai panagal building"),
        ("Thiruvanmiyur", "Thiruvanmiyur, Chennai, Tamil Nadu", "neighborhood", "Chennai", 12.9830, 80.2594, "thiruvanmiyur bus stand beach marundeeswarar temple tidel park"),
        ("Sholinganallur", "Sholinganallur, Chennai, Tamil Nadu", "neighborhood", "Chennai", 12.9010, 80.2279, "sholinganallur junction omr it corridor elcot sez infosys wipro"),
        ("Navalur OMR", "Navalur, OMR, Chennai, Tamil Nadu", "neighborhood", "Chennai", 12.8458, 80.2265, "navalur omr vivira mall marina mall siruseri it park"),
        ("Poonamallee", "Poonamallee, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0489, 80.1098, "poonamallee bypass bus terminus trunk road"),
        ("Chromepet", "Chromepet, Chennai, Tamil Nadu", "neighborhood", "Chennai", 12.9516, 80.1462, "chromepet railway station mit college gst road saravana stores"),
        ("Pallavaram", "Pallavaram, Chennai, Tamil Nadu", "neighborhood", "Chennai", 12.9675, 80.1491, "pallavaram railway station flyover gst road cantt"),
        ("Avadi", "Avadi, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.1147, 80.1009, "avadi railway station hvf tank factory crpf air force"),
        ("Madhavaram", "Madhavaram, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.1488, 80.2306, "madhavaram mofussil bus terminus mmbt milk colony roundtana"),
        ("Royapettah", "Royapettah, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0537, 80.2604, "royapettah express avenue ea mall clock tower hospital"),
        ("Triplicane", "Triplicane, Chennai, Tamil Nadu", "neighborhood", "Chennai", 13.0587, 80.2758, "triplicane parthasarathy temple chepauk stadium qaid e millath"),
        ("Broadway Parrys", "Parrys Corner / Broadway, Chennai, Tamil Nadu", "bus_terminal", "Chennai", 13.0891, 80.2882, "broadway bus terminus parrys corner high court nsc bose road"),

        # Chennai Metro Green Line Stations (St. Thomas Mount to Puratchi Thalaivar Dr. MGR Central)
        ("St. Thomas Mount Metro", "St. Thomas Mount Metro Station, Chennai", "metro_station", "Chennai", 13.0039, 80.1983, "st thomas mount green line metro interchange railway"),
        ("Alandur Metro", "Alandur Metro Station, Chennai", "metro_station", "Chennai", 13.0041, 80.2014, "alandur metro interchange green line blue line asarkhana"),
        ("Ekkattuthangal Metro", "Ekkattuthangal Metro Station, Chennai", "metro_station", "Chennai", 13.0169, 80.2057, "ekkattuthangal metro green line ambal nagar cipet"),
        ("Ashok Nagar Metro", "Ashok Nagar Metro Station, Chennai", "metro_station", "Chennai", 13.0354, 80.2113, "ashok nagar metro green line pillar 100 feet road"),
        ("Vadapalani Metro", "Vadapalani Metro Station, Chennai", "metro_station", "Chennai", 13.0505, 80.2120, "vadapalani metro green line nexus mall"),
        ("Arumbakkam Metro", "Arumbakkam Metro Station, Chennai", "metro_station", "Chennai", 13.0617, 80.2115, "arumbakkam metro green line dg vaishnav college"),
        ("CMBT Metro", "CMBT Metro Station, Koyambedu, Chennai", "metro_station", "Chennai", 13.0694, 80.2078, "cmbt metro green line koyambedu bus terminus"),
        ("Koyambedu Metro", "Koyambedu Metro Station, Chennai", "metro_station", "Chennai", 13.0734, 80.1953, "koyambedu metro green line rohini cinema market"),
        ("Thirumangalam Metro", "Thirumangalam Metro Station, Chennai", "metro_station", "Chennai", 13.0853, 80.1994, "thirumangalam metro green line vr mall anna nagar"),
        ("Anna Nagar Tower Metro", "Anna Nagar Tower Metro Station, Chennai", "metro_station", "Chennai", 13.0848, 80.2097, "anna nagar tower metro green line park a round"),
        ("Anna Nagar East Metro", "Anna Nagar East Metro Station, Chennai", "metro_station", "Chennai", 13.0872, 80.2215, "anna nagar east metro green line roundtana"),
        ("Shenoy Nagar Metro", "Shenoy Nagar Metro Station, Chennai", "metro_station", "Chennai", 13.0784, 80.2285, "shenoy nagar metro green line thiru vi ka park"),
        ("Pachaiyappa Metro", "Pachaiyappa's College Metro Station, Chennai", "metro_station", "Chennai", 13.0772, 80.2372, "pachaiyappa metro green line college poonamallee high road"),
        ("Kilpauk Metro", "Kilpauk Medical College Metro Station, Chennai", "metro_station", "Chennai", 13.0788, 80.2435, "kilpauk metro green line kmc medical college poonamallee high road"),
        ("Nehru Park Metro", "Nehru Park Metro Station, Chennai", "metro_station", "Chennai", 13.0789, 80.2520, "nehru park metro green line sangam cinemas kelly's"),
        ("Egmore Metro", "Chennai Egmore Metro Station, Chennai", "metro_station", "Chennai", 13.0792, 80.2614, "egmore metro green line railway station museum"),
        ("Central Metro", "Puratchi Thalaivar Dr. M.G. Ramachandran Central Metro, Chennai", "metro_station", "Chennai", 13.0827, 80.2755, "central metro green line blue line mgr railway station ripon building"),

        # Chennai Metro Blue Line Stations (Wimco Nagar to Chennai International Airport)
        ("Airport Metro", "Chennai International Airport Metro Station, Chennai", "metro_station", "Chennai", 12.9941, 80.1709, "airport metro blue line terminal maa domestic international"),
        ("Meenambakkam Metro", "Meenambakkam Metro Station, Chennai", "metro_station", "Chennai", 12.9878, 80.1764, "meenambakkam metro blue line jain college"),
        ("Nanganallur Road Metro", "Nanganallur Road Metro Station, Chennai", "metro_station", "Chennai", 12.9972, 80.1912, "nanganallur road metro blue line anjaneyar temple"),
        ("Guindy Metro", "Guindy Metro Station, Chennai", "metro_station", "Chennai", 13.0067, 80.2025, "guindy metro blue line race course industrial estate"),
        ("Little Mount Metro", "Little Mount Metro Station, Chennai", "metro_station", "Chennai", 13.0163, 80.2212, "little mount metro blue line saidapet raj bhavan"),
        ("Saidapet Metro", "Saidapet Metro Station, Chennai", "metro_station", "Chennai", 13.0238, 80.2269, "saidapet metro blue line panagal building"),
        ("Nandanam Metro", "Nandanam Metro Station, Chennai", "metro_station", "Chennai", 13.0315, 80.2384, "nandanam metro blue line ymca fanepet venkatanarayana"),
        ("Teynampet Metro", "Teynampet Metro Station, Chennai", "metro_station", "Chennai", 13.0409, 80.2486, "teynampet metro blue line siet college anna arivalayam"),
        ("AG-DMS Metro", "AG-DMS Metro Station, Anna Salai, Chennai", "metro_station", "Chennai", 13.0465, 80.2492, "ag dms metro blue line directorate medical services gemini"),
        ("Thousand Lights Metro", "Thousand Lights Metro Station, Chennai", "metro_station", "Chennai", 13.0583, 80.2543, "thousand lights metro blue line anna flyover spencer plaza"),
        ("LIC Metro", "LIC Metro Station, Anna Salai, Chennai", "metro_station", "Chennai", 13.0682, 80.2642, "lic metro blue line mount road express avenue spencer"),
        ("Government Estate Metro", "Government Estate Metro Station, Chennai", "metro_station", "Chennai", 13.0699, 80.2741, "government estate metro blue line omandurar secretariat chepauk"),
        ("High Court Metro", "High Court Metro Station, Parrys, Chennai", "metro_station", "Chennai", 13.0877, 80.2872, "high court metro blue line broadway parrys madras high court"),
        ("Mannadi Metro", "Mannadi Metro Station, Chennai", "metro_station", "Chennai", 13.0945, 80.2891, "mannadi metro blue line george town"),
        ("Washermanpet Metro", "Washermanpet Metro Station, Chennai", "metro_station", "Chennai", 13.1070, 80.2820, "washermanpet metro blue line sir theagaraya college"),

        # Key Tamil Nadu Cities (Intercity destinations)
        ("Chennai", "Chennai, Tamil Nadu", "city", "Chennai", 13.0827, 80.2707, "chennai madras tamil nadu capital"),
        ("Salem", "Salem, Tamil Nadu", "city", "Salem", 11.6643, 78.1460, "salem junction bus stand new bus stand steel plant yercald mangos"),
        ("Coimbatore", "Coimbatore, Tamil Nadu", "city", "Coimbatore", 11.0168, 76.9558, "coimbatore covai gandhipuram railway station peelamedu textile manchester south"),
        ("Madurai", "Madurai, Tamil Nadu", "city", "Madurai", 9.9252, 78.1198, "madurai meenakshi amman temple mattuthavani railway station temple city"),
        ("Vellore", "Vellore, Tamil Nadu", "city", "Vellore", 12.9165, 79.1325, "vellore fort cmc hospital golden temple sripuram new bus stand katpadi"),
        ("Trichy", "Tiruchirappalli (Trichy), Tamil Nadu", "city", "Trichy", 10.7905, 78.7047, "trichy tiruchirappalli rockfort srirangam central bus stand junction"),
        ("Tirunelveli", "Tirunelveli, Tamil Nadu", "city", "Tirunelveli", 8.7139, 77.7567, "tirunelveli nellai halwa junction new bus stand palayamkottai"),
        ("Erode", "Erode, Tamil Nadu", "city", "Erode", 11.3410, 77.7172, "erode junction turmeric textile central bus stand"),
        ("Tiruppur", "Tiruppur, Tamil Nadu", "city", "Tiruppur", 11.1085, 77.3411, "tiruppur knitwear export hub old bus stand new bus stand"),
        ("Thanjavur", "Thanjavur, Tamil Nadu", "city", "Thanjavur", 10.7870, 79.1378, "thanjavur big temple brihadeeswara royal palace old bus stand"),
        ("Dindigul", "Dindigul, Tamil Nadu", "city", "Dindigul", 10.3673, 77.9803, "dindigul lock biryani fort junction bus stand"),
        ("Kanchipuram", "Kanchipuram, Tamil Nadu", "city", "Kanchipuram", 12.8342, 79.7036, "kanchipuram silk saree ekambareswarar kamakshi amman"),
        ("Tiruvannamalai", "Tiruvannamalai, Tamil Nadu", "city", "Tiruvannamalai", 12.2253, 79.0747, "tiruvannamalai annamalaiyar girivalam temple deepam"),
        ("Hosur", "Hosur, Tamil Nadu", "city", "Hosur", 12.7409, 77.8253, "hosur sipcot industrial town bangalore border ashok leyland"),
        ("Pondicherry", "Puducherry (Pondicherry)", "city", "Pondicherry", 11.9416, 79.8083, "pondicherry puducherry white town promenade beach auroville french quarter"),
        ("Bengaluru", "Bengaluru, Karnataka", "city", "Bengaluru", 12.9716, 77.5946, "bengaluru bangalore majestic electronic city silk board kempagowda")
    ]

    cursor.executemany("""
    INSERT INTO locations (name, display_name, category, city, latitude, longitude, keywords)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, locations)

    # Seed Metro Stations in order for line distance and station lookup
    green_line_stations = [
        ("Central Metro", 1, 13.0827, 80.2755),
        ("Egmore Metro", 2, 13.0792, 80.2614),
        ("Nehru Park Metro", 3, 13.0789, 80.2520),
        ("Kilpauk Metro", 4, 13.0788, 80.2435),
        ("Pachaiyappa Metro", 5, 13.0772, 80.2372),
        ("Shenoy Nagar Metro", 6, 13.0784, 80.2285),
        ("Anna Nagar East Metro", 7, 13.0872, 80.2215),
        ("Anna Nagar Tower Metro", 8, 13.0848, 80.2097),
        ("Thirumangalam Metro", 9, 13.0853, 80.1994),
        ("Koyambedu Metro", 10, 13.0734, 80.1953),
        ("CMBT Metro", 11, 13.0694, 80.2078),
        ("Arumbakkam Metro", 12, 13.0617, 80.2115),
        ("Vadapalani Metro", 13, 13.0505, 80.2120),
        ("Ashok Nagar Metro", 14, 13.0354, 80.2113),
        ("Ekkattuthangal Metro", 15, 13.0169, 80.2057),
        ("Alandur Metro", 16, 13.0041, 80.2014),
        ("St. Thomas Mount Metro", 17, 13.0039, 80.1983)
    ]
    for name, idx, lat, lon in green_line_stations:
        cursor.execute("INSERT INTO metro_stations (station_name, line, order_index, latitude, longitude) VALUES (?, ?, ?, ?, ?)",
                       (name, "Green Line", idx, lat, lon))

    blue_line_stations = [
        ("Washermanpet Metro", 1, 13.1070, 80.2820),
        ("Mannadi Metro", 2, 13.0945, 80.2891),
        ("High Court Metro", 3, 13.0877, 80.2872),
        ("Central Metro", 4, 13.0827, 80.2755),
        ("Government Estate Metro", 5, 13.0699, 80.2741),
        ("LIC Metro", 6, 13.0682, 80.2642),
        ("Thousand Lights Metro", 7, 13.0583, 80.2543),
        ("AG-DMS Metro", 8, 13.0465, 80.2492),
        ("Teynampet Metro", 9, 13.0409, 80.2486),
        ("Nandanam Metro", 10, 13.0315, 80.2384),
        ("Saidapet Metro", 11, 13.0238, 80.2269),
        ("Little Mount Metro", 12, 13.0163, 80.2212),
        ("Guindy Metro", 13, 13.0067, 80.2025),
        ("Alandur Metro", 14, 13.0041, 80.2014),
        ("Nanganallur Road Metro", 15, 12.9972, 80.1912),
        ("Meenambakkam Metro", 16, 12.9878, 80.1764),
        ("Airport Metro", 17, 12.9941, 80.1709)
    ]
    for name, idx, lat, lon in blue_line_stations:
        cursor.execute("INSERT INTO metro_stations (station_name, line, order_index, latitude, longitude) VALUES (?, ?, ?, ?, ?)",
                       (name, "Blue Line", idx, lat, lon))

    # Seed Suburban Stations (South Line & MRTS)
    suburban_stations_data = [
        ("Chennai Beach", "South Line", 1, 13.0924, 80.2934),
        ("Chennai Fort", "South Line", 2, 13.0837, 80.2852),
        ("Chennai Park", "South Line", 3, 13.0788, 80.2747),
        ("Chennai Egmore", "South Line", 4, 13.0792, 80.2614),
        ("Chetpet", "South Line", 5, 13.0712, 80.2432),
        ("Nungambakkam", "South Line", 6, 13.0610, 80.2389),
        ("Kodambakkam", "South Line", 7, 13.0518, 80.2273),
        ("Mambalam (T. Nagar)", "South Line", 8, 13.0396, 80.2248),
        ("Saidapet", "South Line", 9, 13.0213, 80.2231),
        ("Guindy", "South Line", 10, 13.0067, 80.2025),
        ("St. Thomas Mount", "South Line", 11, 13.0039, 80.1983),
        ("Pazhavanthangal", "South Line", 12, 12.9902, 80.1834),
        ("Meenambakkam", "South Line", 13, 12.9865, 80.1741),
        ("Tirusulam (Airport)", "South Line", 14, 12.9791, 80.1652),
        ("Pallavaram", "South Line", 15, 12.9675, 80.1491),
        ("Chromepet", "South Line", 16, 12.9516, 80.1462),
        ("Tambaram Sanatorium", "South Line", 17, 12.9367, 80.1287),
        ("Tambaram", "South Line", 18, 12.9249, 80.1000),
        ("Perungalathur", "South Line", 19, 12.9038, 80.0827),
        ("Vandalur", "South Line", 20, 12.8894, 80.0768),
        ("Chengalpattu", "South Line", 21, 12.6841, 79.9836),

        # MRTS Line (Chennai Beach to Velachery)
        ("Chintadripet", "MRTS Line", 3, 13.0765, 80.2731),
        ("Chepauk", "MRTS Line", 4, 13.0645, 80.2801),
        ("Thirumayilai (Mylapore)", "MRTS Line", 6, 13.0336, 80.2694),
        ("Mandaveli", "MRTS Line", 7, 13.0250, 80.2642),
        ("Kasturiba Nagar", "MRTS Line", 10, 13.0065, 80.2520),
        ("Indira Nagar", "MRTS Line", 11, 12.9984, 80.2510),
        ("Thiruvanmiyur", "MRTS Line", 12, 12.9868, 80.2505),
        ("Taramani", "MRTS Line", 13, 12.9772, 80.2398),
        ("Perungudi", "MRTS Line", 14, 12.9682, 80.2325),
        ("Velachery", "MRTS Line", 15, 12.9756, 80.2206)
    ]
    for name, line, idx, lat, lon in suburban_stations_data:
        cursor.execute("INSERT INTO suburban_stations (station_name, line, order_index, latitude, longitude) VALUES (?, ?, ?, ?, ?)",
                       (name, line, idx, lat, lon))

    conn.commit()
    conn.close()
    print(f"Database initialized and seeded successfully at: {DB_PATH}")

if __name__ == "__main__":
    init_database()
