"""
Unified Intelligent Transportation System (UITS)
Unified Launcher Script.
Initializes database if required and starts the web application server.
"""

import os
import sys
import webbrowser
import time
import threading

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from database.init_db import init_database, DB_PATH
from backend.server import run_server

def ensure_database():
    if not os.path.exists(DB_PATH):
        print("📦 Initializing UITS SQLite database and seeding locations...")
        init_database()
    else:
        print("✓ SQLite database verified at:", DB_PATH)

def open_browser(port):
    time.sleep(1.2)
    url = f"http://localhost:{port}"
    print(f"🌐 Launching default browser to: {url}")
    try:
        webbrowser.open(url)
    except Exception as e:
        print(f"Notice: Could not automatically open browser ({e}). Please navigate to {url} manually.")

def main():
    print("=" * 70)
    print("🚦 UNIFIED INTELLIGENT TRANSPORTATION SYSTEM (UITS)")
    print("Real GPS Distance + Real Transport Rates + Smart Route Recommendation")
    print("=" * 70)

    ensure_database()

    port = 5000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass

    # Start browser launcher thread
    threading.Thread(target=open_browser, args=(port,), daemon=True).start()

    # Start the server (blocks and serves)
    run_server(port=port, host="0.0.0.0")

if __name__ == "__main__":
    main()
