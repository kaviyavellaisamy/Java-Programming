"""
Automated Verification and Test Suite for UITS.
Tests all 6 specified routes and validates distance, fares, time, Smart Scores, and recommendation.
"""

import sys
import os

ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from backend.routes.api import handle_api_request

TEST_CASES = [
    ("Shenoy Nagar", "Koyambedu CMBT", "Local Urban Short Journey"),
    ("Anna Nagar", "T. Nagar", "Local City Mid-Distance"),
    ("Vadapalani", "Guindy", "Metro & Road Corridor"),
    ("Tambaram", "Velachery", "Suburban Corridor"),
    ("Chennai", "Salem", "Intercity Long Distance"),
    ("Chennai", "Coimbatore", "Intercity Express Long Distance")
]

def run_tests():
    print("=" * 80)
    print("🚦 RUNNING UITS AUTOMATED TEST SUITE")
    print("=" * 80)

    all_passed = True

    for idx, (source, dest, desc) in enumerate(TEST_CASES, start=1):
        print(f"\n[Test {idx}]: {source} ➔ {dest} ({desc})")
        status_code, response = handle_api_request(
            "POST",
            "/api/routes/compare",
            {},
            {"source": source, "destination": dest}
        )

        if status_code != 200 or not response.get("success"):
            print(f"❌ FAILED with status {status_code}: {response.get('error')}")
            all_passed = False
            continue

        data = response["data"]
        dist = data["distance_km"]
        recom = data["recommendation"]
        options = data["options"]

        print(f"  • Source: {data['source']['name']} ({data['source']['latitude']:.4f}, {data['source']['longitude']:.4f})")
        print(f"  • Destination: {data['destination']['name']} ({data['destination']['latitude']:.4f}, {data['destination']['longitude']:.4f})")
        print(f"  • Road Distance: {dist:.2f} KM (Route Type: {data['route_type']})")
        print(f"  • Total Modes Evaluated: {len(options)}")

        # Check options
        avail_count = sum(1 for o in options if o["is_available"])
        unavail_count = sum(1 for o in options if not o["is_available"])
        print(f"  • Available Modes: {avail_count} | Unavailable Modes: {unavail_count}")

        # Check Best Route
        if recom:
            print(f"  🏆 BEST ROUTE: {recom['best_mode']}")
            print(f"     Time: {recom['estimated_time_minutes']} min | Cost: ₹{recom['estimated_cost']} | Smart Score: {recom['smart_score']}/100")
            print(f"     Status: {recom['status']}")
        else:
            print("  ❌ No recommendation generated!")
            all_passed = False

        # Specific assertions for each test case
        if idx in (1, 2, 3):
            # Local journeys should have Rapido Bike and Auto available
            bike_opt = next((o for o in options if o["code"] == "rapido_bike"), None)
            if not (bike_opt and bike_opt["is_available"]):
                print("  ❌ Expected Rapido Bike to be available for local trip")
                all_passed = False

        if idx in (5, 6):
            # Intercity journeys (> 300km) should have Rapido Bike and Metro UNAVAILABLE
            bike_opt = next((o for o in options if o["code"] == "rapido_bike"), None)
            metro_opt = next((o for o in options if o["code"] == "metro_train"), None)
            if bike_opt and bike_opt["is_available"]:
                print("  ❌ Rapido Bike should NOT be available for intercity trip")
                all_passed = False
            if metro_opt and metro_opt["is_available"]:
                print("  ❌ Metro Train should NOT be available for intercity trip")
                all_passed = False

        print("  ✓ Passed validation.")

    print("\n" + "=" * 80)
    if all_passed:
        print("🎉 ALL 6 TEST CASES PASSED SUCCESSFULLY!")
    else:
        print("⚠️ SOME TESTS FAILED. PLEASE CHECK LOGS ABOVE.")
    print("=" * 80)

if __name__ == "__main__":
    run_tests()
