@echo off
title Unified Intelligent Transportation System (UITS)
echo ========================================================================
echo   UNIFIED INTELLIGENT TRANSPORTATION SYSTEM (UITS)
echo   Real GPS Distance + Real Transport Rates + Smart Route Recommendation
echo ========================================================================
echo.

:: Detect Python
where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    python run_uits.py
    goto end
)

where py >nul 2>nul
if %ERRORLEVEL% equ 0 (
    py run_uits.py
    goto end
)

if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" (
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" run_uits.py
    goto end
)

echo [ERROR] Python not found in PATH or standard directories.
echo Please install Python 3.10+ from python.org
pause

:end
